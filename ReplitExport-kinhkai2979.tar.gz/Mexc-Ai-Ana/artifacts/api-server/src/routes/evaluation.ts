import { Router } from "express";
import {
  computeEvaluationSummary,
  computeHourlyEvaluation,
  computeDailyEvaluation,
} from "../lib/evaluation";

const router = Router();

// Simple in-process cache so evaluation doesn't re-read files on every request
const evalCache = {
  summary: null as { data: unknown; ts: number } | null,
  hourly:  null as { data: unknown; ts: number } | null,
  daily:   null as { data: unknown; ts: number } | null,
};
const EVAL_TTL = 5 * 60 * 1000; // 5-minute cache

/**
 * GET /api/evaluation/summary
 * Overall AI signal accuracy and performance metrics.
 */
router.get("/evaluation/summary", (_req, res) => {
  try {
    if (evalCache.summary && Date.now() - evalCache.summary.ts < EVAL_TTL) {
      return res.json(evalCache.summary.data);
    }
    const data = computeEvaluationSummary();
    evalCache.summary = { data, ts: Date.now() };
    return res.json(data);
  } catch (err) {
    console.error("evaluation/summary error:", err);
    return res.status(500).json({ error: "Không thể tính toán đánh giá" });
  }
});

/**
 * GET /api/evaluation/hourly
 * Signal performance broken down by UTC hour of day (0–23).
 */
router.get("/evaluation/hourly", (_req, res) => {
  try {
    if (evalCache.hourly && Date.now() - evalCache.hourly.ts < EVAL_TTL) {
      return res.json(evalCache.hourly.data);
    }
    const data = computeHourlyEvaluation();
    evalCache.hourly = { data, ts: Date.now() };
    return res.json(data);
  } catch (err) {
    console.error("evaluation/hourly error:", err);
    return res.status(500).json({ error: "Không thể tính toán đánh giá theo giờ" });
  }
});

/**
 * GET /api/evaluation/daily?days=30
 * Signal performance broken down by calendar day (last N days).
 */
router.get("/evaluation/daily", (req, res) => {
  try {
    const days = Math.min(parseInt((req.query.days as string) || "30", 10), 90);
    if (evalCache.daily && Date.now() - evalCache.daily.ts < EVAL_TTL) {
      return res.json(evalCache.daily.data);
    }
    const data = computeDailyEvaluation(days);
    evalCache.daily = { data, ts: Date.now() };
    return res.json(data);
  } catch (err) {
    console.error("evaluation/daily error:", err);
    return res.status(500).json({ error: "Không thể tính toán đánh giá theo ngày" });
  }
});

export default router;
