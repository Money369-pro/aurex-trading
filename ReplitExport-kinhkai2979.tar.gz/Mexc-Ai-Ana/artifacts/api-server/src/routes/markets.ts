import { Router } from "express";
import { getAllExchangeSymbols, getCachedSymbols, getCacheAge } from "../lib/exchanges";

const router = Router();

/**
 * GET /api/markets/all-symbols
 * Returns unified symbol list from Binance, OKX, Bybit, MEXC, KuCoin.
 * Supports ?quote=USDT to filter by quote asset.
 * Supports ?q=BTC to text-search symbols.
 */
router.get("/markets/all-symbols", async (req, res) => {
  try {
    const symbols = await getAllExchangeSymbols();

    let filtered = symbols;

    const quote = (req.query.quote as string | undefined)?.toUpperCase();
    if (quote) filtered = filtered.filter((s) => s.quote === quote);

    const q = (req.query.q as string | undefined)?.toUpperCase();
    if (q) filtered = filtered.filter((s) => s.symbol.includes(q) || s.base.includes(q));

    const page = parseInt((req.query.page as string) || "1", 10);
    const limit = Math.min(parseInt((req.query.limit as string) || "500", 10), 2000);
    const start = (page - 1) * limit;
    const paginated = filtered.slice(start, start + limit);

    return res.json({
      total: filtered.length,
      page,
      limit,
      cacheAgeSeconds: getCacheAge(),
      symbols: paginated,
    });
  } catch (err) {
    console.error("markets/all-symbols error:", err);
    return res.status(500).json({ error: "Không thể tải danh sách sàn" });
  }
});

/**
 * POST /api/markets/refresh
 * Triggers an immediate cache refresh (admin use).
 */
router.post("/markets/refresh", async (_req, res) => {
  try {
    const symbols = await getAllExchangeSymbols();
    return res.json({ refreshed: true, total: symbols.length, cacheAgeSeconds: getCacheAge() });
  } catch (err) {
    return res.status(500).json({ error: "Refresh failed" });
  }
});

export default router;
