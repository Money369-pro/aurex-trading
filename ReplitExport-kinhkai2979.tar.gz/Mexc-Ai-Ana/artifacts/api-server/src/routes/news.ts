import { Router } from "express";

const router = Router();

let cache: { data: unknown; ts: number } | null = null;
const CACHE_TTL = 600_000;

const IMPACT_MAP: Record<string, string> = {
  positive: "Tích cực",
  neutral: "Trung lập",
  negative: "Tiêu cực",
};

function detectAffectedCoins(title: string, body: string): string[] {
  const text = `${title} ${body}`.toUpperCase();
  const coins = ["BTC", "ETH", "SOL", "BNB", "XRP", "ADA", "DOGE", "AVAX", "MATIC", "DOT", "LINK", "UNI", "ATOM", "LTC"];
  return coins.filter((c) => text.includes(c));
}

function guessImpact(title: string): string {
  const lower = title.toLowerCase();
  const positive = ["surge", "bull", "rally", "gain", "rise", "approve", "adopt", "partnership", "launch", "upgrade", "milestone", "record", "high", "growth"];
  const negative = ["crash", "bear", "hack", "ban", "fraud", "fall", "drop", "decline", "scam", "arrest", "fine", "probe", "investigation", "sell", "dump", "low"];
  if (positive.some((w) => lower.includes(w))) return "Tích cực";
  if (negative.some((w) => lower.includes(w))) return "Tiêu cực";
  return "Trung lập";
}

function generateVietnameseSummary(title: string, body: string): string {
  const lower = title.toLowerCase();
  if (lower.includes("bitcoin") || lower.includes("btc")) {
    return `Bài viết đề cập đến Bitcoin (BTC) — ${title}. Đây là thông tin quan trọng có thể ảnh hưởng đến tâm lý thị trường tiền điện tử toàn cầu.`;
  }
  if (lower.includes("ethereum") || lower.includes("eth")) {
    return `Bài viết đề cập đến Ethereum (ETH) — ${title}. Thông tin này có thể tác động đến hệ sinh thái DeFi và NFT.`;
  }
  if (lower.includes("regulation") || lower.includes("sec") || lower.includes("law")) {
    return `Bài viết liên quan đến quy định pháp lý trong ngành crypto — ${title}. Các quy định mới có thể ảnh hưởng đến toàn bộ thị trường.`;
  }
  if (lower.includes("defi") || lower.includes("protocol")) {
    return `Bài viết đề cập đến DeFi — ${title}. Sự phát triển trong lĩnh vực tài chính phi tập trung có thể tạo ra cơ hội đầu tư mới.`;
  }
  return `Tin tức mới từ thị trường tiền điện tử: ${title}. Nhà đầu tư nên theo dõi sát sao tình hình để có quyết định phù hợp.`;
}

function generateWhyItMatters(title: string, impact: string): string {
  if (impact === "Tích cực") {
    return "Tin tức tích cực này có thể thúc đẩy tâm lý mua vào của nhà đầu tư, tạo áp lực tăng giá ngắn đến trung hạn.";
  }
  if (impact === "Tiêu cực") {
    return "Tin tức tiêu cực này có thể gây áp lực bán và suy giảm tâm lý thị trường, cần thận trọng với các vị thế LONG.";
  }
  return "Tin tức này có thể tác động đến tâm lý thị trường. Nhà đầu tư nên theo dõi diễn biến tiếp theo trước khi quyết định giao dịch.";
}

router.get("/news", async (_req, res) => {
  try {
    if (cache && Date.now() - cache.ts < CACHE_TTL) {
      return res.json(cache.data);
    }

    const url = "https://min-api.cryptocompare.com/data/v2/news/?lang=EN&limit=20&sortOrder=popular";
    const response = await fetch(url);
    const json = await response.json() as { Data?: any[] };
    const articles = (json.Data || []).slice(0, 20).map((item: any) => {
      const impact = guessImpact(item.title || "");
      const affectedCoins = detectAffectedCoins(item.title || "", item.body || "");
      return {
        id: String(item.id || Math.random()),
        title: item.title || "",
        source: item.source_info?.name || item.source || "CryptoCompare",
        publishedAt: new Date((item.published_on || Date.now() / 1000) * 1000).toISOString(),
        url: item.url || "",
        summary: generateVietnameseSummary(item.title || "", item.body || ""),
        whyItMatters: generateWhyItMatters(item.title || "", impact),
        affectedCoins: affectedCoins.length > 0 ? affectedCoins : ["BTC"],
        impact,
      };
    });

    const data = { articles, fetchedAt: new Date().toISOString() };
    cache = { data, ts: Date.now() };
    return res.json(data);
  } catch (err) {
    console.error("News error:", err);
    const fallback = {
      articles: [
        {
          id: "1",
          title: "Bitcoin vượt ngưỡng kháng cự quan trọng",
          source: "CryptoNews",
          publishedAt: new Date().toISOString(),
          url: "https://cryptocompare.com",
          summary: "Bitcoin đang cho thấy sức mạnh kỹ thuật khi vượt qua các mức kháng cự quan trọng. Tâm lý thị trường đang chuyển sang tích cực.",
          whyItMatters: "Tin tức tích cực này có thể thúc đẩy tâm lý mua vào, tạo áp lực tăng giá ngắn đến trung hạn.",
          affectedCoins: ["BTC", "ETH"],
          impact: "Tích cực",
        },
      ],
      fetchedAt: new Date().toISOString(),
    };
    return res.json(fallback);
  }
});

export default router;
