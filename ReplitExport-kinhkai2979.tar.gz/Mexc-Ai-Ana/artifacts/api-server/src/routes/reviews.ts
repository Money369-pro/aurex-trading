import { Router } from "express";
import {
  loadSignals, loadReviews, saveReview, markSignalReviewed,
  getPendingSignals, type SignalReview
} from "../lib/storage";
import { reviewSignal } from "../lib/review";

const router = Router();

router.get("/signals", (_req, res) => {
  try {
    const signals = loadSignals();
    return res.json({ signals: signals.slice().reverse(), total: signals.length });
  } catch (err) {
    console.error("Signals error:", err);
    return res.status(500).json({ error: "Không thể tải danh sách tín hiệu" });
  }
});

router.get("/reviews", (_req, res) => {
  try {
    const reviews = loadReviews();
    return res.json({ reviews: reviews.slice().reverse(), total: reviews.length });
  } catch (err) {
    console.error("Reviews error:", err);
    return res.status(500).json({ error: "Không thể tải danh sách đánh giá" });
  }
});

router.get("/reviews/stats", (_req, res) => {
  try {
    const signals = loadSignals();
    const reviews = loadReviews();

    const totalSignals = signals.length;
    const reviewedSignals = reviews.length;

    if (reviewedSignals === 0) {
      return res.json({
        totalSignals,
        reviewedSignals: 0,
        totalReviewed: 0,
        winRate: 0,
        tp1Rate: 0,
        tp2Rate: 0,
        slRate: 0,
        bySymbol: [],
        byDirection: {
          LONG: { wins: 0, total: 0, winRate: 0 },
          SHORT: { wins: 0, total: 0, winRate: 0 },
        },
        bestSetups: [],
        averageConfidence: 0,
      });
    }

    const wins = reviews.filter((r) => r.tp1Reached || r.tp2Reached || r.directionCorrect).length;
    const tp1Count = reviews.filter((r) => r.tp1Reached).length;
    const tp2Count = reviews.filter((r) => r.tp2Reached).length;
    const slCount = reviews.filter((r) => r.slHit).length;

    const winRate = Math.round((wins / reviewedSignals) * 100);
    const tp1Rate = Math.round((tp1Count / reviewedSignals) * 100);
    const tp2Rate = Math.round((tp2Count / reviewedSignals) * 100);
    const slRate = Math.round((slCount / reviewedSignals) * 100);

    const symbolMap = new Map<string, { wins: number; total: number }>();
    for (const r of reviews) {
      const isWin = r.tp1Reached || r.tp2Reached || r.directionCorrect;
      const existing = symbolMap.get(r.symbol) || { wins: 0, total: 0 };
      symbolMap.set(r.symbol, {
        wins: existing.wins + (isWin ? 1 : 0),
        total: existing.total + 1,
      });
    }
    const bySymbol = Array.from(symbolMap.entries())
      .map(([symbol, { wins: w, total: t }]) => ({
        symbol,
        wins: w,
        total: t,
        winRate: Math.round((w / t) * 100),
      }))
      .sort((a, b) => b.winRate - a.winRate);

    const longReviews = reviews.filter((r) => r.originalDirection === "LONG");
    const shortReviews = reviews.filter((r) => r.originalDirection === "SHORT");
    const longWins = longReviews.filter((r) => r.tp1Reached || r.tp2Reached || r.directionCorrect).length;
    const shortWins = shortReviews.filter((r) => r.tp1Reached || r.tp2Reached || r.directionCorrect).length;

    const byDirection = {
      LONG: {
        wins: longWins,
        total: longReviews.length,
        winRate: longReviews.length > 0 ? Math.round((longWins / longReviews.length) * 100) : 0,
      },
      SHORT: {
        wins: shortWins,
        total: shortReviews.length,
        winRate: shortReviews.length > 0 ? Math.round((shortWins / shortReviews.length) * 100) : 0,
      },
    };

    const setupMap = new Map<string, { wins: number; total: number }>();
    for (const r of reviews) {
      const key = `${r.symbol}|${r.originalDirection}`;
      const isWin = r.tp1Reached || r.tp2Reached || r.directionCorrect;
      const existing = setupMap.get(key) || { wins: 0, total: 0 };
      setupMap.set(key, { wins: existing.wins + (isWin ? 1 : 0), total: existing.total + 1 });
    }
    const bestSetups = Array.from(setupMap.entries())
      .filter(([, v]) => v.total >= 1)
      .map(([key, { wins: w, total: t }]) => {
        const [symbol, direction] = key.split("|");
        return { symbol, direction, winRate: Math.round((w / t) * 100), count: t };
      })
      .sort((a, b) => b.winRate - a.winRate)
      .slice(0, 10);

    const averageConfidence = Math.round(
      reviews.reduce((s, r) => s + r.confidence, 0) / reviewedSignals
    );

    return res.json({
      totalSignals,
      reviewedSignals,
      totalReviewed: reviewedSignals,
      winRate,
      tp1Rate,
      tp2Rate,
      slRate,
      bySymbol,
      byDirection,
      bestSetups,
      averageConfidence,
    });
  } catch (err) {
    console.error("Stats error:", err);
    return res.status(500).json({ error: "Không thể tính thống kê" });
  }
});

router.post("/reviews/run", async (_req, res) => {
  try {
    const pending = getPendingSignals();
    if (pending.length === 0) {
      return res.json({ reviewed: 0, message: "Không có tín hiệu nào cần đánh giá lúc này" });
    }

    let count = 0;
    for (const signal of pending) {
      const review = await reviewSignal(signal);
      if (review) {
        saveReview(review);
        markSignalReviewed(signal.id);
        count++;
      }
    }

    return res.json({
      reviewed: count,
      message: `Đã đánh giá ${count} tín hiệu thành công`,
    });
  } catch (err) {
    console.error("Run review error:", err);
    return res.status(500).json({ error: "Không thể chạy đánh giá" });
  }
});

export async function startAutoReviewer() {
  const INTERVAL = 60 * 60 * 1000;
  setInterval(async () => {
    try {
      const pending = getPendingSignals();
      if (pending.length === 0) return;
      console.log(`[AutoReviewer] Reviewing ${pending.length} pending signals...`);
      for (const signal of pending) {
        const review = await reviewSignal(signal);
        if (review) {
          saveReview(review);
          markSignalReviewed(signal.id);
        }
      }
      console.log(`[AutoReviewer] Done`);
    } catch (err) {
      console.error("[AutoReviewer] Error:", err);
    }
  }, INTERVAL);
}

export default router;
