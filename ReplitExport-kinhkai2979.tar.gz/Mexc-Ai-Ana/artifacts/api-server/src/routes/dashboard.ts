import { Router } from "express";
import { getFuturesTickers, getFuturesTicker, getKlines } from "../lib/mexc";
import { calcRSI, calcEMA, calcMACD, calcVolumeChange, determineTrend, calcScore } from "../lib/indicators";

const router = Router();

let cache: { data: unknown; ts: number } | null = null;
const CACHE_TTL = 60_000;

router.get("/dashboard", async (_req, res) => {
  try {
    if (cache && Date.now() - cache.ts < CACHE_TTL) {
      return res.json(cache.data);
    }

    const [btcKlines, ethKlines, solKlines, allTickers] = await Promise.all([
      getKlines("BTC_USDT", "Min60", 100),
      getKlines("ETH_USDT", "Min60", 100),
      getKlines("SOL_USDT", "Min60", 100),
      getFuturesTickers(),
    ]);

    function buildPriceInfo(symbol: string, klines: typeof btcKlines) {
      const closes = klines.map((k) => k.close);
      const ticker = allTickers.find((t) => t.symbol === symbol);
      const price = ticker ? ticker.lastPrice : closes[closes.length - 1] || 0;
      const change24h = ticker ? ticker.riseFallRate * 100 : 0;
      const volume24h = ticker ? ticker.volume24 : 0;
      return { symbol: symbol.replace("_", "/"), price, change24h, volume24h };
    }

    const btc = buildPriceInfo("BTC_USDT", btcKlines);
    const eth = buildPriceInfo("ETH_USDT", ethKlines);
    const sol = buildPriceInfo("SOL_USDT", solKlines);

    const byVolume = [...allTickers]
      .sort((a, b) => b.volume24 - a.volume24)
      .slice(0, 30);

    const signalPromises = byVolume.slice(0, 15).map(async (ticker) => {
      try {
        const klines = await getKlines(ticker.symbol, "Min60", 60);
        if (klines.length < 30) return null;
        const closes = klines.map((k) => k.close);
        const vols = klines.map((k) => k.vol);
        const ema20Arr = calcEMA(closes, 20);
        const ema50Arr = calcEMA(closes, 50);
        const rsi = calcRSI(closes, 14);
        const macd = calcMACD(closes);
        const volumeChange = calcVolumeChange(vols);
        const ema20 = ema20Arr[ema20Arr.length - 1] || 0;
        const ema50 = ema50Arr[ema50Arr.length - 1] || 0;
        const trendH1 = determineTrend(closes, ema20, ema50);
        const { score, signalStrength, direction } = calcScore(
          ema20, ema50, macd.macdValue, macd.signal, rsi, volumeChange, trendH1, trendH1
        );
        if (score < 65) return null;
        return {
          symbol: ticker.symbol.replace("_", "/"),
          score,
          direction,
          change24h: ticker.riseFallRate * 100,
          price: ticker.lastPrice,
          signalStrength,
        };
      } catch {
        return null;
      }
    });

    const signalResults = await Promise.all(signalPromises);
    const topSignals = signalResults
      .filter(Boolean)
      .sort((a: any, b: any) => b.score - a.score)
      .slice(0, 5);

    const bullishCount = topSignals.filter((s: any) => s?.direction === "LONG").length;
    let marketSentiment = "Trung Tính";
    if (bullishCount >= 4) marketSentiment = "Tham Lam";
    else if (bullishCount >= 3) marketSentiment = "Tích Cực";
    else if (bullishCount <= 1) marketSentiment = "Sợ Hãi";
    else marketSentiment = "Thận Trọng";

    const fearGreedIndex = Math.round(40 + (bullishCount / 5) * 40 + (btc.change24h > 0 ? 10 : 0));

    const data = {
      btc, eth, sol,
      marketSentiment,
      fearGreedIndex: Math.min(100, Math.max(0, fearGreedIndex)),
      topSignals,
      updatedAt: new Date().toISOString(),
    };

    cache = { data, ts: Date.now() };
    return res.json(data);
  } catch (err) {
    console.error("Dashboard error:", err);
    return res.status(500).json({ error: "Không thể tải dữ liệu dashboard" });
  }
});

export default router;
