import { Router } from "express";
import { getFuturesTickers, getKlines } from "../lib/mexc";
import { calcRSI, calcEMA, calcMACD, calcVolumeChange, determineTrend, calcScore } from "../lib/indicators";

const router = Router();

let cache: { data: unknown; ts: number } | null = null;
const CACHE_TTL = 120_000;

router.get("/scanner", async (_req, res) => {
  try {
    if (cache && Date.now() - cache.ts < CACHE_TTL) {
      return res.json(cache.data);
    }

    const allTickers = await getFuturesTickers();
    const top100 = [...allTickers]
      .sort((a, b) => b.volume24 - a.volume24)
      .slice(0, 100);

    const CONCURRENCY = 10;
    const results: unknown[] = [];

    for (let i = 0; i < top100.length; i += CONCURRENCY) {
      const batch = top100.slice(i, i + CONCURRENCY);
      const batchResults = await Promise.all(
        batch.map(async (ticker) => {
          try {
            const [klinesH1, klinesH4] = await Promise.all([
              getKlines(ticker.symbol, "Min60", 60),
              getKlines(ticker.symbol, "Hour4", 60),
            ]);
            if (klinesH1.length < 30) return null;

            const closesH1 = klinesH1.map((k) => k.close);
            const closesH4 = klinesH4.length >= 20 ? klinesH4.map((k) => k.close) : closesH1;
            const vols = klinesH1.map((k) => k.vol);

            const ema20Arr = calcEMA(closesH1, 20);
            const ema50Arr = calcEMA(closesH1, 50);
            if (!ema20Arr.length || !ema50Arr.length) return null;

            const rsi = calcRSI(closesH1, 14);
            const macd = calcMACD(closesH1);
            const volumeChange = calcVolumeChange(vols);
            const ema20 = ema20Arr[ema20Arr.length - 1];
            const ema50 = ema50Arr[ema50Arr.length - 1];

            const ema20H4Arr = calcEMA(closesH4, 20);
            const ema50H4Arr = calcEMA(closesH4, 50);
            const ema20H4 = ema20H4Arr[ema20H4Arr.length - 1] || ema20;
            const ema50H4 = ema50H4Arr[ema50H4Arr.length - 1] || ema50;

            const trendH1 = determineTrend(closesH1, ema20, ema50);
            const trendH4 = determineTrend(closesH4, ema20H4, ema50H4);
            const { score, signalStrength, direction } = calcScore(
              ema20, ema50, macd.macdValue, macd.signal, rsi, volumeChange, trendH1, trendH4
            );

            return {
              symbol: ticker.symbol.replace("_", "/"),
              price: ticker.lastPrice,
              change24h: ticker.riseFallRate * 100,
              volume24h: ticker.volume24,
              rsi: Math.round(rsi * 10) / 10,
              ema20: Math.round(ema20 * 10000) / 10000,
              ema50: Math.round(ema50 * 10000) / 10000,
              macdValue: Math.round(macd.macdValue * 10000) / 10000,
              macdSignal: Math.round(macd.signal * 10000) / 10000,
              macdHistogram: Math.round(macd.histogram * 10000) / 10000,
              trendH1,
              trendH4,
              score,
              signalStrength,
              direction,
              volumeChange: Math.round(volumeChange * 10) / 10,
            };
          } catch {
            return null;
          }
        })
      );
      results.push(...batchResults.filter(Boolean));
    }

    const pairs = (results as any[]).sort((a, b) => b.score - a.score);

    const data = {
      pairs,
      scannedAt: new Date().toISOString(),
      totalScanned: pairs.length,
    };

    cache = { data, ts: Date.now() };
    return res.json(data);
  } catch (err) {
    console.error("Scanner error:", err);
    return res.status(500).json({ error: "Không thể quét thị trường" });
  }
});

export default router;
