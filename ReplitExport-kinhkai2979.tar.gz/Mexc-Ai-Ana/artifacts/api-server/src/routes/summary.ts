import { Router } from "express";
import { getFuturesTickers, getKlines } from "../lib/mexc";
import { calcRSI, calcEMA, calcMACD, calcVolumeChange, calcScore, determineTrend } from "../lib/indicators";

const router = Router();

let cache: { data: unknown; ts: number } | null = null;
const CACHE_TTL = 300_000;

router.get("/summary", async (_req, res) => {
  try {
    if (cache && Date.now() - cache.ts < CACHE_TTL) {
      return res.json(cache.data);
    }

    const allTickers = await getFuturesTickers();
    const top10 = [...allTickers].sort((a, b) => b.volume24 - a.volume24).slice(0, 10);

    const analyses = await Promise.all(
      top10.map(async (t) => {
        try {
          const klines = await getKlines(t.symbol, "Min60", 60);
          if (klines.length < 30) return null;
          const closes = klines.map((k) => k.close);
          const vols = klines.map((k) => k.vol);
          const ema20Arr = calcEMA(closes, 20);
          const ema50Arr = calcEMA(closes, 50);
          const rsi = calcRSI(closes, 14);
          const macd = calcMACD(closes);
          const volumeChange = calcVolumeChange(vols);
          const ema20 = ema20Arr[ema20Arr.length - 1] || 0;
          const ema50 = ema50Arr[ema50Arr.length - 1] || 0;
          const trend = determineTrend(closes, ema20, ema50);
          const { score, direction } = calcScore(ema20, ema50, macd.macdValue, macd.signal, rsi, volumeChange, trend, trend);
          return { symbol: t.symbol, rsi, trend, score, direction, change24h: t.riseFallRate * 100 };
        } catch { return null; }
      })
    );

    const valid = analyses.filter(Boolean) as any[];
    const bullish = valid.filter((a) => a.direction === "LONG");
    const bearish = valid.filter((a) => a.direction === "SHORT");
    const avgScore = valid.reduce((s, a) => s + a.score, 0) / (valid.length || 1);
    const avgRsi = valid.reduce((s, a) => s + a.rsi, 0) / (valid.length || 1);
    const uptrend = valid.filter((a) => a.trend === "Uptrend").length;
    const marketBullish = bullish.length > bearish.length;
    const topOpps = valid.filter((a) => a.score >= 65).sort((a, b) => b.score - a.score).slice(0, 3);

    const today = new Date().toLocaleDateString("vi-VN", { weekday: "long", year: "numeric", month: "long", day: "numeric" });

    const overview = marketBullish
      ? `Ngày ${today}, thị trường tiền điện tử đang có xu hướng tích cực. ${uptrend}/${valid.length} cặp trong top 10 đang trong xu hướng tăng. ` +
        `Điểm tín hiệu trung bình là ${avgScore.toFixed(0)}/100. RSI trung bình ${avgRsi.toFixed(1)} cho thấy thị trường đang ${avgRsi > 60 ? "tiếp cận vùng quá mua" : avgRsi < 40 ? "ở vùng quá bán" : "trong vùng trung tính"}. ` +
        `Dòng tiền đang có xu hướng vào thị trường, tâm lý nhà đầu tư khá tích cực.`
      : `Ngày ${today}, thị trường tiền điện tử đang có xu hướng thận trọng. ${uptrend}/${valid.length} cặp trong top 10 đang trong xu hướng tăng. ` +
        `Điểm tín hiệu trung bình là ${avgScore.toFixed(0)}/100. RSI trung bình ${avgRsi.toFixed(1)}. ` +
        `Áp lực bán đang chiếm ưu thế, nhà đầu tư nên thận trọng và quản lý rủi ro chặt chẽ.`;

    const bullishScenario = bullish.length > 0
      ? `Kịch bản tăng: Nếu BTC và các altcoin giữ được các mức hỗ trợ quan trọng và tiếp tục nhận dòng tiền mới, thị trường có thể bứt phá lên cao hơn. ` +
        `Các cặp tiềm năng nhất hiện tại bao gồm: ${bullish.slice(0, 3).map((a) => a.symbol.replace("_USDT", "")).join(", ")}. ` +
        `Nhà đầu tư có thể xem xét vào lệnh LONG với stop loss chặt chẽ tại các vùng hỗ trợ kỹ thuật.`
      : "Kịch bản tăng: Nếu thị trường tạo được đáy và có tín hiệu đảo chiều mạnh, dòng tiền có thể quay trở lại. Cần theo dõi sát BTC để xác nhận xu hướng trước khi vào lệnh.";

    const bearishScenario = bearish.length > 0
      ? `Kịch bản giảm: Nếu áp lực bán tiếp tục gia tăng và các mức hỗ trợ quan trọng bị phá vỡ, thị trường có thể tiếp tục điều chỉnh. ` +
        `Cần đặt stop loss chặt chẽ và giảm tỷ trọng vị thế. Theo dõi các cặp đang trong xu hướng giảm: ${bearish.slice(0, 3).map((a) => a.symbol.replace("_USDT", "")).join(", ")}.`
      : "Kịch bản giảm: Nếu BTC không giữ được các mức hỗ trợ hiện tại và dòng tiền rút ra, thị trường có thể điều chỉnh. Nhà đầu tư nên có kế hoạch quản lý rủi ro rõ ràng.";

    const keyRisks = [
      "Biến động từ các quyết định lãi suất của FED và các ngân hàng trung ương",
      "Áp lực quy định từ SEC và các cơ quan quản lý trên toàn cầu",
      `RSI trung bình ${avgRsi.toFixed(1)} — ${avgRsi > 65 ? "rủi ro điều chỉnh do thị trường đang trong vùng quá mua" : avgRsi < 35 ? "cần theo dõi tín hiệu phục hồi" : "thị trường ổn định nhưng cần xác nhận xu hướng"}`,
      "Biến động đột ngột từ các sự kiện macro toàn cầu (địa chính trị, kinh tế vĩ mô)",
      "Rủi ro thanh khoản trong giai đoạn biến động cao",
    ];

    const topOpportunities = topOpps.length > 0
      ? topOpps.map((a) => `${a.symbol.replace("_USDT", "/USDT")} — Điểm tín hiệu: ${a.score}/100, hướng: ${a.direction === "LONG" ? "LONG (Mua)" : "SHORT (Bán)"}`)
      : ["Thị trường đang trong giai đoạn tích lũy, chờ tín hiệu rõ ràng hơn trước khi vào lệnh"];

    const data = {
      overview,
      bullishScenario,
      bearishScenario,
      keyRisks,
      topOpportunities,
      generatedAt: new Date().toISOString(),
    };

    cache = { data, ts: Date.now() };
    return res.json(data);
  } catch (err) {
    console.error("Summary error:", err);
    return res.status(500).json({ error: "Không thể tạo tóm tắt thị trường" });
  }
});

export default router;
