import { Router } from "express";
import { getKlines, getFuturesTicker } from "../lib/mexc";
import {
  calcRSI, calcEMA, calcMACD, calcVolumeChange,
  calcSupportResistance, determineTrend,
  calcBollingerBands, calcATR, detectRegime, calcAdvancedScore,
} from "../lib/indicators";
import {
  explainRSI, explainEMA, explainMACD, explainVolume, explainTrend,
  explainBollingerBands, explainATR,
  generateTradingSuggestionReasoning,
} from "../lib/vietnamese";
import { saveSignal, generateSignalId, loadSignals } from "../lib/storage";

const router = Router();

const cache = new Map<string, { data: unknown; ts: number }>();
const CACHE_TTL = 60_000;

const KNOWN_QUOTES = ["USDT", "USDC", "BTC", "ETH", "BNB", "BUSD"];

function normalizeSymbol(raw: string): string {
  const upper = raw.toUpperCase();
  if (upper.includes("_")) return upper;
  if (upper.includes("/")) return upper.replace("/", "_");
  if (upper.includes("-")) return upper.replace("-", "_");
  for (const q of KNOWN_QUOTES) {
    if (upper.endsWith(q) && upper.length > q.length) {
      return `${upper.slice(0, upper.length - q.length)}_${q}`;
    }
  }
  return upper;
}

function symbolToDisplay(normalized: string): string {
  return normalized.replace("_", "/");
}

function last(arr: number[]): number {
  return arr[arr.length - 1] || 0;
}

router.get("/coin/:symbol", (req, res) => handleCoinDetail(req, res));
router.get("/coins/:symbol", (req, res) => handleCoinDetail(req, res));

async function handleCoinDetail(req: any, res: any) {
  const symbol = normalizeSymbol(req.params.symbol);

  const cached = cache.get(symbol);
  if (cached && Date.now() - cached.ts < CACHE_TTL) return res.json(cached.data);

  try {
    const [klinesH1, klinesH4, klinesM15, klinesD1, ticker] = await Promise.all([
      getKlines(symbol, "Min60", 200),
      getKlines(symbol, "Hour4", 100),
      getKlines(symbol, "Min15", 100),
      getKlines(symbol, "Day1", 60),
      getFuturesTicker(symbol),
    ]);

    if (!klinesH1.length || !ticker) {
      return res.status(404).json({ error: "Không tìm thấy cặp giao dịch" });
    }

    const round = (n: number, d = 6) => Math.round(n * 10 ** d) / 10 ** d;

    // ── H1 arrays ──────────────────────────────────────────────────────────
    const closesH1 = klinesH1.map((k) => k.close);
    const highsH1  = klinesH1.map((k) => k.high);
    const lowsH1   = klinesH1.map((k) => k.low);
    const volsH1   = klinesH1.map((k) => k.vol);

    // ── H4 / M15 / D1 arrays ──────────────────────────────────────────────
    const closesH4  = klinesH4.length  >= 30 ? klinesH4.map((k) => k.close)  : closesH1;
    const highsH4   = klinesH4.length  >= 30 ? klinesH4.map((k) => k.high)   : highsH1;
    const lowsH4    = klinesH4.length  >= 30 ? klinesH4.map((k) => k.low)    : lowsH1;
    const closesM15 = klinesM15.length >= 30 ? klinesM15.map((k) => k.close) : closesH1;
    const closesD1  = klinesD1.length  >= 15 ? klinesD1.map((k) => k.close)  : closesH1;

    // ── Multi-period RSI ───────────────────────────────────────────────────
    const rsi7  = round(calcRSI(closesH1, 7),  2);
    const rsi14 = round(calcRSI(closesH1, 14), 2);
    const rsi21 = round(calcRSI(closesH1, 21), 2);

    // ── EMA stack H1 ──────────────────────────────────────────────────────
    const ema20  = round(last(calcEMA(closesH1, 20)),  4);
    const ema50  = round(last(calcEMA(closesH1, 50)),  4);
    const ema100 = round(last(calcEMA(closesH1, 100)), 4);
    const ema200 = round(last(calcEMA(closesH1, 200)), 4);

    // ── MACD ──────────────────────────────────────────────────────────────
    const macd = calcMACD(closesH1);

    // ── Bollinger Bands (20,2) on H1 ──────────────────────────────────────
    const bb = calcBollingerBands(closesH1, 20, 2);

    // ── ATR ───────────────────────────────────────────────────────────────
    const atr     = round(calcATR(highsH1, lowsH1, closesH1, 14), 6);
    const price   = ticker.lastPrice;
    const atrPct  = round(price > 0 ? (atr / price) * 100 : 0, 3);

    // ── Volume ────────────────────────────────────────────────────────────
    const volumeChange = calcVolumeChange(volsH1);

    // ── Support / Resistance ──────────────────────────────────────────────
    const { support, resistance } = calcSupportResistance(highsH1, lowsH1, closesH1);

    // ── Trends (H1, H4, M15, D1) ─────────────────────────────────────────
    const ema20H4  = round(last(calcEMA(closesH4, 20)),  4);
    const ema50H4  = round(last(calcEMA(closesH4, 50)),  4);
    const ema20M15 = round(last(calcEMA(closesM15, 20)), 4);
    const ema50M15 = round(last(calcEMA(closesM15, 50)), 4);
    const ema20D1  = round(last(calcEMA(closesD1, 10)),  4);
    const ema50D1  = round(last(calcEMA(closesD1, 20)),  4);

    const trendH1  = determineTrend(closesH1, ema20, ema50);
    const trendH4  = determineTrend(closesH4, ema20H4, ema50H4);
    const trendM15 = determineTrend(closesM15, ema20M15, ema50M15);
    const trendD1  = determineTrend(closesD1, ema20D1, ema50D1);

    // ── Market Regime ─────────────────────────────────────────────────────
    const { regime, strength: regimeStrength } = detectRegime(
      closesH1, ema20, ema50, ema100, ema200, atr, bb.width, bb.percentB,
    );

    // ── Advanced Signal Score ─────────────────────────────────────────────
    const {
      score, signalStrength, direction,
      reasons, trendScore, momentumScore, volumeScore, volatilityScore,
    } = calcAdvancedScore(
      price, ema20, ema50, ema100, ema200,
      rsi7, rsi14, rsi21,
      macd.macdValue, macd.signal, macd.histogram,
      volumeChange, atr, bb.width, bb.percentB,
      trendH1, trendH4, regime,
    );

    // ── Trade Levels ──────────────────────────────────────────────────────
    const atrVal = atr > 0 ? atr : price * 0.01;
    let entryMin: number, entryMax: number, stopLoss: number, tp1: number, tp2: number;

    if (direction === "LONG" || direction === "HOLD") {
      entryMin  = round(price * 0.999, 4);
      entryMax  = round(price * 1.001, 4);
      stopLoss  = round(Math.max(support, price - atrVal * 2), 4);
      tp1       = round(price + atrVal * 2, 4);
      tp2       = round(Math.min(resistance, price + atrVal * 4), 4);
    } else {
      entryMin  = round(price * 0.999, 4);
      entryMax  = round(price * 1.001, 4);
      stopLoss  = round(Math.min(resistance, price + atrVal * 2), 4);
      tp1       = round(price - atrVal * 2, 4);
      tp2       = round(Math.max(support, price - atrVal * 4), 4);
    }

    const data = {
      symbol:        symbolToDisplay(symbol),
      price,
      change24h:     round(ticker.riseFallRate * 100, 2),
      volume24h:     ticker.volume24,

      // RSI multi-timeframe
      rsi:    rsi14,
      rsi7,
      rsi14,
      rsi21,

      // EMA stack
      ema20,
      ema50,
      ema100,
      ema200,

      // MACD
      macdValue:     round(macd.macdValue, 6),
      macdSignal:    round(macd.signal, 6),
      macdHistogram: round(macd.histogram, 6),

      // Bollinger Bands
      bbUpper:   round(bb.upper, 6),
      bbMiddle:  round(bb.middle, 6),
      bbLower:   round(bb.lower, 6),
      bbWidth:   round(bb.width, 4),
      bbPercent: round(bb.percentB, 4),

      // ATR
      atr,
      atrPercent: atrPct,

      // Structure
      support:    round(support, 6),
      resistance: round(resistance, 6),
      trendH1,
      trendH4,
      trendM15,
      trendD1,

      // Regime
      regime,
      regimeStrength,

      // Signal
      score,
      signalStrength,
      direction,
      reasons,
      trendScore,
      momentumScore,
      volumeScore,
      volatilityScore,

      // Explanations
      rsiExplanation:    explainRSI(rsi14),
      emaExplanation:    explainEMA(price, ema20, ema50),
      macdExplanation:   explainMACD(macd.macdValue, macd.signal, macd.histogram),
      volumeExplanation: explainVolume(volumeChange, ticker.volume24),
      trendExplanation:  explainTrend(trendH1, trendH4, symbol),
      bbExplanation:     explainBollingerBands(price, bb.upper, bb.lower, bb.width, bb.percentB),
      atrExplanation:    explainATR(atr, price),

      suggestion: {
        direction,
        entryMin,
        entryMax,
        stopLoss,
        takeProfit1: tp1,
        takeProfit2: tp2,
        confidence:  score,
        reasoning:   generateTradingSuggestionReasoning(
          symbol, direction, score, rsi14,
          ema20, ema50, macd.macdValue, macd.signal,
          trendH1, trendH4, support, resistance,
        ),
      },
    };

    cache.set(symbol, { data, ts: Date.now() });

    // ── Auto-save signal ──────────────────────────────────────────────────
    if (direction !== "HOLD") {
      try {
        const hourKey = Math.floor(Date.now() / 3_600_000);
        const signalId = generateSignalId(symbol, hourKey);
        if (!loadSignals().find((s) => s.id === signalId)) {
          saveSignal({
            id: signalId,
            symbol: symbolToDisplay(symbol),
            timestamp: Date.now(),
            direction,
            entryPrice: price,
            stopLoss,
            takeProfit1: tp1,
            takeProfit2: tp2,
            confidence: score,
            reasons: reasons.join(" | "),
            trendM15,
            trendH1,
            trendH4,
            trendD1,
            rsi: rsi14,
            ema20,
            ema50,
            macdValue: round(macd.macdValue, 6),
            score,
            reviewed: false,
          });
        }
      } catch (saveErr) {
        console.error("Signal save error (non-fatal):", saveErr);
      }
    }

    return res.json(data);
  } catch (err) {
    console.error("Coin detail error:", err);
    return res.status(500).json({ error: "Không thể tải dữ liệu coin" });
  }
}

export default router;
