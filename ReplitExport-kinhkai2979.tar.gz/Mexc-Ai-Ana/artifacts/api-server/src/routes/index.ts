import { Router, type IRouter } from "express";
import healthRouter from "./health";
import dashboardRouter from "./dashboard";
import scannerRouter from "./scanner";
import coinsRouter from "./coins";
import newsRouter from "./news";
import summaryRouter from "./summary";
import reviewsRouter from "./reviews";
import marketsRouter from "./markets";
import evaluationRouter from "./evaluation";

const router: IRouter = Router();

router.use(healthRouter);
router.use(dashboardRouter);
router.use(scannerRouter);
router.use(coinsRouter);
router.use(newsRouter);
router.use(summaryRouter);
router.use(reviewsRouter);
router.use(marketsRouter);
router.use(evaluationRouter);

export default router;
