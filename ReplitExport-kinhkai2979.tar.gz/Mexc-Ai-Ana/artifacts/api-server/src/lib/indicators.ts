// ─── Basic Indicators ───────────────────────────────────────────────────────

export function calcEMA(prices: number[], period: number): number[] {
  if (prices.length < period) return [];
  const k = 2 / (period + 1);
  const result: number[] = [];
  let ema = prices.slice(0, period).reduce((a, b) => a + b, 0) / period;
  result.push(ema);
  for (let i = period; i < prices.length; i++) {
    ema = prices[i] * k + ema * (1 - k);
    result.push(ema);
  }
  return result;
}

export function calcRSI(prices: number[], period: number = 14): number {
  if (prices.length < period + 1) return 50;
  let gains = 0, losses = 0;
  for (let i = 1; i <= period; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff >= 0) gains += diff; else losses -= diff;
  }
  let avgGain = gains / period;
  let avgLoss = losses / period;
  for (let i = period + 1; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    avgGain = (avgGain * (period - 1) + Math.max(diff, 0)) / period;
    avgLoss = (avgLoss * (period - 1) + Math.max(-diff, 0)) / period;
  }
  if (avgLoss === 0) return 100;
  return 100 - 100 / (1 + avgGain / avgLoss);
}

export interface MACDResult {
  macdValue: number;
  signal: number;
  histogram: number;
}

export function calcMACD(
  prices: number[],
  fastPeriod = 12,
  slowPeriod = 26,
  signalPeriod = 9,
): MACDResult {
  const fast = calcEMA(prices, fastPeriod);
  const slow = calcEMA(prices, slowPeriod);
  if (!fast.length || !slow.length) return { macdValue: 0, signal: 0, histogram: 0 };
  const offset = slowPeriod - fastPeriod;
  const macdLine: number[] = [];
  for (let i = 0; i < slow.length; i++) macdLine.push(fast[i + offset] - slow[i]);
  const signalLine = calcEMA(macdLine, signalPeriod);
  if (!signalLine.length) return { macdValue: macdLine[macdLine.length - 1] || 0, signal: 0, histogram: 0 };
  const lastMacd = macdLine[macdLine.length - 1];
  const lastSignal = signalLine[signalLine.length - 1];
  return { macdValue: lastMacd, signal: lastSignal, histogram: lastMacd - lastSignal };
}

export function calcVolumeChange(vols: number[]): number {
  if (vols.length < 10) return 0;
  const recent = vols.slice(-5).reduce((a, b) => a + b, 0) / 5;
  const prev = vols.slice(-10, -5).reduce((a, b) => a + b, 0) / 5;
  if (prev === 0) return 0;
  return ((recent - prev) / prev) * 100;
}

export function calcSupportResistance(
  highs: number[],
  lows: number[],
  closes: number[],
): { support: number; resistance: number } {
  if (closes.length === 0) return { support: 0, resistance: 0 };
  const recentHighs = highs.slice(-20);
  const recentLows = lows.slice(-20);
  return { support: Math.min(...recentLows), resistance: Math.max(...recentHighs) };
}

export function determineTrend(closes: number[], ema20: number, ema50: number): string {
  if (closes.length === 0) return "Sideways";
  const last = closes[closes.length - 1];
  if (last > ema20 && ema20 > ema50) return "Uptrend";
  if (last < ema20 && ema20 < ema50) return "Downtrend";
  return "Sideways";
}

// ─── New Indicators ──────────────────────────────────────────────────────────

export interface BollingerBands {
  upper: number;
  middle: number;
  lower: number;
  /** (upper - lower) / middle — measures band width relative to price */
  width: number;
  /** (price - lower) / (upper - lower) — 0 = at lower, 1 = at upper */
  percentB: number;
}

export function calcBollingerBands(
  prices: number[],
  period = 20,
  multiplier = 2,
): BollingerBands {
  if (prices.length < period) {
    const p = prices[prices.length - 1] || 0;
    return { upper: p, middle: p, lower: p, width: 0, percentB: 0.5 };
  }
  const slice = prices.slice(-period);
  const middle = slice.reduce((a, b) => a + b, 0) / period;
  const variance = slice.reduce((sum, p) => sum + Math.pow(p - middle, 2), 0) / period;
  const std = Math.sqrt(variance);
  const upper = middle + multiplier * std;
  const lower = middle - multiplier * std;
  const price = prices[prices.length - 1];
  const width = middle > 0 ? (upper - lower) / middle : 0;
  const range = upper - lower;
  const percentB = range > 0 ? (price - lower) / range : 0.5;
  return { upper, middle, lower, width, percentB };
}

/** Average True Range — measures market volatility */
export function calcATR(
  highs: number[],
  lows: number[],
  closes: number[],
  period = 14,
): number {
  if (highs.length < 2) return 0;
  const trs: number[] = [];
  for (let i = 1; i < highs.length; i++) {
    trs.push(Math.max(
      highs[i] - lows[i],
      Math.abs(highs[i] - closes[i - 1]),
      Math.abs(lows[i] - closes[i - 1]),
    ));
  }
  const recent = trs.slice(-period);
  return recent.length > 0 ? recent.reduce((a, b) => a + b, 0) / recent.length : 0;
}

// ─── Market Regime ────────────────────────────────────────────────────────────

export type MarketRegime =
  | "Uptrend"
  | "Downtrend"
  | "Sideways"
  | "HighVolatility"
  | "Breakout";

export interface RegimeResult {
  regime: MarketRegime;
  strength: number; // 0–100
}

export function detectRegime(
  closes: number[],
  ema20: number,
  ema50: number,
  ema100: number,
  ema200: number,
  atr: number,
  bbWidth: number,
  bbPercent: number,
): RegimeResult {
  const price = closes[closes.length - 1] || 0;
  const atrPct = price > 0 ? (atr / price) * 100 : 0;

  // High volatility: ATR% > 4% or bands extremely wide
  if (atrPct > 4 || bbWidth > 0.1) {
    return { regime: "HighVolatility", strength: Math.min(100, Math.round(atrPct * 15)) };
  }

  // Breakout: price outside Bollinger Bands
  if (bbPercent > 1.05 || bbPercent < -0.05) {
    return { regime: "Breakout", strength: 80 };
  }

  // Count EMA stacking layers (each contributes 1 to bull/bear count)
  const bullLayers = [
    price > ema20,
    ema20 > ema50,
    ema50 > ema100,
    ema100 > ema200,
  ].filter(Boolean).length;
  const bearLayers = [
    price < ema20,
    ema20 < ema50,
    ema50 < ema100,
    ema100 < ema200,
  ].filter(Boolean).length;

  if (bullLayers >= 3) {
    return { regime: "Uptrend", strength: Math.min(100, bullLayers * 22 + 10) };
  }
  if (bearLayers >= 3) {
    return { regime: "Downtrend", strength: Math.min(100, bearLayers * 22 + 10) };
  }
  return { regime: "Sideways", strength: 40 };
}

// ─── Legacy Score (used by scanner for speed) ─────────────────────────────────

export interface ScoreResult {
  score: number;
  signalStrength: string;
  direction: string;
}

export function calcScore(
  ema20: number,
  ema50: number,
  macdValue: number,
  macdSignal: number,
  rsi: number,
  volumeChange: number,
  trendH1: string,
  trendH4: string,
): ScoreResult {
  let bullPoints = 0;
  let bearPoints = 0;

  if (ema20 > ema50) bullPoints += 25; else bearPoints += 25;
  if (macdValue > macdSignal) bullPoints += 20; else bearPoints += 20;
  if (rsi >= 45 && rsi <= 65) { bullPoints += 15; bearPoints += 15; }
  if (Math.abs(volumeChange) > 20) { bullPoints += 10; bearPoints += 10; }

  const trendsAligned =
    (trendH1 === "Uptrend" && trendH4 === "Uptrend") ||
    (trendH1 === "Downtrend" && trendH4 === "Downtrend");
  if (trendsAligned) { bullPoints += 10; bearPoints += 10; }

  const score = Math.max(bullPoints, bearPoints);
  const signalStrength = score >= 80 ? "Rất Mạnh" : score >= 65 ? "Trung Bình" : "Yếu";
  const direction = bullPoints >= bearPoints ? "LONG" : "SHORT";
  return { score, signalStrength, direction };
}

// ─── Advanced Score (used by coin detail) ─────────────────────────────────────

export interface AdvancedScoreResult {
  score: number;
  signalStrength: string;
  direction: "LONG" | "SHORT" | "HOLD";
  reasons: string[];
  trendScore: number;
  momentumScore: number;
  volumeScore: number;
  volatilityScore: number;
}

interface WeightedFactor {
  value: number; // +1 bull, -1 bear, 0 neutral
  weight: number;
  bullReason?: string;
  bearReason?: string;
}

export function calcAdvancedScore(
  price: number,
  ema20: number,
  ema50: number,
  ema100: number,
  ema200: number,
  rsi7: number,
  rsi14: number,
  rsi21: number,
  macdValue: number,
  macdSignal: number,
  macdHistogram: number,
  volumeChange: number,
  atr: number,
  bbWidth: number,
  bbPercent: number,
  trendH1: string,
  trendH4: string,
  regime: MarketRegime,
): AdvancedScoreResult {
  const factors: WeightedFactor[] = [
    // ── Trend layer (30 pts max) ──
    {
      value: ema20 > ema50 ? 1 : -1,
      weight: 12,
      bullReason: "EMA20 trên EMA50 (xu hướng tăng)",
      bearReason: "EMA20 dưới EMA50 (xu hướng giảm)",
    },
    {
      value: ema50 > ema100 ? 1 : -1,
      weight: 8,
      bullReason: "EMA50 trên EMA100 (cấu trúc tăng trung hạn)",
      bearReason: "EMA50 dưới EMA100 (cấu trúc giảm trung hạn)",
    },
    {
      value: ema100 > ema200 ? 1 : -1,
      weight: 5,
      bullReason: "EMA100 trên EMA200 (xu hướng dài hạn tăng)",
      bearReason: "EMA100 dưới EMA200 (xu hướng dài hạn giảm)",
    },
    {
      value: price > ema20 ? 1 : -1,
      weight: 5,
      bullReason: "Giá trên EMA20 (lực cầu ngắn hạn)",
      bearReason: "Giá dưới EMA20 (lực cung ngắn hạn)",
    },
    // ── TF Trend (16 pts max) ──
    {
      value: trendH1 === "Uptrend" ? 1 : trendH1 === "Downtrend" ? -1 : 0,
      weight: 8,
      bullReason: "Xu hướng H1 đang tăng",
      bearReason: "Xu hướng H1 đang giảm",
    },
    {
      value: trendH4 === "Uptrend" ? 1 : trendH4 === "Downtrend" ? -1 : 0,
      weight: 8,
      bullReason: "Xu hướng H4 đang tăng (xác nhận đa khung)",
      bearReason: "Xu hướng H4 đang giảm (xác nhận đa khung)",
    },
    // ── Momentum (25 pts max) ──
    {
      value: macdValue > macdSignal ? 1 : -1,
      weight: 12,
      bullReason: "MACD cắt lên đường Signal (bullish crossover)",
      bearReason: "MACD dưới đường Signal (bearish crossover)",
    },
    {
      value: macdHistogram > 0 ? 1 : -1,
      weight: 8,
      bullReason: "MACD histogram dương (đà tăng mạnh dần)",
      bearReason: "MACD histogram âm (đà giảm mạnh dần)",
    },
    {
      value: rsi14 > 52 ? 1 : rsi14 < 48 ? -1 : 0,
      weight: 8,
      bullReason: `RSI(14) = ${rsi14.toFixed(1)} đang trên vùng trung tính`,
      bearReason: `RSI(14) = ${rsi14.toFixed(1)} đang dưới vùng trung tính`,
    },
    {
      value: rsi7 > rsi14 ? 1 : rsi7 < rsi14 ? -1 : 0,
      weight: 5,
      bullReason: "RSI(7) trên RSI(14) — đà tăng ngắn hạn",
      bearReason: "RSI(7) dưới RSI(14) — đà giảm ngắn hạn",
    },
    {
      value: rsi21 > 50 ? 1 : -1,
      weight: 4,
      bullReason: "RSI(21) trên 50 — xu hướng trung hạn tích cực",
      bearReason: "RSI(21) dưới 50 — xu hướng trung hạn tiêu cực",
    },
    // ── Volume (10 pts max) ──
    {
      value: volumeChange > 20 ? 1 : volumeChange < -20 ? -1 : 0,
      weight: 10,
      bullReason: `Khối lượng tăng ${volumeChange.toFixed(0)}% — xác nhận tín hiệu`,
      bearReason: `Khối lượng giảm ${Math.abs(volumeChange).toFixed(0)}% — tín hiệu yếu`,
    },
    // ── Bollinger / Volatility (9 pts max) ──
    {
      value: bbPercent > 0.65 ? 1 : bbPercent < 0.35 ? -1 : 0,
      weight: 5,
      bullReason: "Giá gần dải BB trên — đà tăng mạnh",
      bearReason: "Giá gần dải BB dưới — đà giảm mạnh",
    },
    {
      value: regime === "Uptrend" ? 1 : regime === "Downtrend" ? -1 : 0,
      weight: 7,
      bullReason: "Chế độ thị trường: xu hướng tăng xác nhận",
      bearReason: "Chế độ thị trường: xu hướng giảm xác nhận",
    },
  ];

  const maxWeight = factors.reduce((s, f) => s + f.weight, 0);
  let net = 0;
  let trendNet = 0, momentumNet = 0, volumeNet = 0, volNet = 0;

  for (let i = 0; i < factors.length; i++) {
    const contribution = factors[i].value * factors[i].weight;
    net += contribution;
    if (i < 6) trendNet += contribution;
    else if (i < 11) momentumNet += contribution;
    else if (i < 12) volumeNet += contribution;
    else volNet += contribution;
  }

  const direction: "LONG" | "SHORT" = net >= 0 ? "LONG" : "SHORT";
  const absNet = Math.abs(net);
  const confidence = absNet / maxWeight; // 0–1

  // Score: 50 (neutral) → 100 (fully aligned)
  const rawScore = Math.round(50 + confidence * 50);
  const score = Math.min(100, Math.max(0, rawScore));

  // RSI extreme override: avoid signals in overbought/oversold extremes
  const rsiExtreme = (direction === "LONG" && rsi14 > 78) || (direction === "SHORT" && rsi14 < 22);
  const finalDirection: "LONG" | "SHORT" | "HOLD" =
    score < 65 || rsiExtreme ? "HOLD" : direction;

  // Build reasons from the strongest contributing factors
  const reasons: string[] = [];
  const sortedFactors = [...factors]
    .filter((f) => f.value !== 0)
    .sort((a, b) => Math.abs(b.value * b.weight) - Math.abs(a.value * a.weight));

  for (const f of sortedFactors) {
    if (reasons.length >= 5) break;
    const aligned = (direction === "LONG" && f.value > 0) || (direction === "SHORT" && f.value < 0);
    const text = f.value > 0 ? f.bullReason : f.bearReason;
    if (text) reasons.push(`${aligned ? "✓" : "✗"} ${text}`);
  }

  if (finalDirection === "HOLD") {
    reasons.push("⏸ Tín hiệu chưa đủ mạnh — chờ xác nhận thêm");
  }
  if (rsiExtreme) {
    reasons.push(`⚠ RSI(14) = ${rsi14.toFixed(1)} — ${rsi14 > 78 ? "vùng quá mua cực đoan" : "vùng quá bán cực đoan"}`);
  }

  let signalStrength: string;
  if (score >= 85) signalStrength = "Rất Mạnh";
  else if (score >= 75) signalStrength = "Mạnh";
  else if (score >= 65) signalStrength = "Trung Bình";
  else signalStrength = "Yếu — Chờ";

  const trendMaxW = 38;
  const momentumMaxW = 37;
  const volumeMaxW = 10;
  const volMaxW = 12;

  return {
    score,
    signalStrength,
    direction: finalDirection,
    reasons,
    trendScore: Math.round(((trendNet + trendMaxW) / (2 * trendMaxW)) * 100),
    momentumScore: Math.round(((momentumNet + momentumMaxW) / (2 * momentumMaxW)) * 100),
    volumeScore: Math.round(((volumeNet + volumeMaxW) / (2 * volumeMaxW)) * 100),
    volatilityScore: Math.round(((volNet + volMaxW) / (2 * volMaxW)) * 100),
  };
}
