import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = path.join(__dirname, "../../data");
const SIGNALS_FILE = path.join(DATA_DIR, "signals.json");
const REVIEWS_FILE = path.join(DATA_DIR, "reviews.json");

export interface SavedSignal {
  id: string;
  symbol: string;
  timestamp: number;
  direction: string;
  entryPrice: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  confidence: number;
  reasons: string;
  trendM15: string;
  trendH1: string;
  trendH4: string;
  trendD1: string;
  rsi: number;
  ema20: number;
  ema50: number;
  macdValue: number;
  score: number;
  reviewed: boolean;
}

export interface SignalReview {
  id: string;
  signalId: string;
  symbol: string;
  reviewedAt: number;
  originalDirection: string;
  entryPrice: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  confidence: number;
  currentPrice: number;
  outcome: string;
  directionCorrect: boolean;
  tp1Reached: boolean;
  tp2Reached: boolean;
  slHit: boolean;
  currentTrendH1: string;
  currentTrendH4: string;
  stillValid: boolean;
  reflection: string;
  whatChanged: string;
  lesson: string;
  priceChangePct: number;
  signalTimestamp: number;
}

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

function readJSON<T>(file: string, fallback: T): T {
  try {
    if (!fs.existsSync(file)) return fallback;
    return JSON.parse(fs.readFileSync(file, "utf-8")) as T;
  } catch {
    return fallback;
  }
}

function writeJSON(file: string, data: unknown) {
  ensureDataDir();
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf-8");
}

export function loadSignals(): SavedSignal[] {
  return readJSON<SavedSignal[]>(SIGNALS_FILE, []);
}

export function saveSignal(signal: SavedSignal) {
  const signals = loadSignals();
  const existing = signals.findIndex((s) => s.id === signal.id);
  if (existing >= 0) {
    signals[existing] = signal;
  } else {
    signals.push(signal);
  }
  writeJSON(SIGNALS_FILE, signals);
}

export function markSignalReviewed(signalId: string) {
  const signals = loadSignals();
  const idx = signals.findIndex((s) => s.id === signalId);
  if (idx >= 0) {
    signals[idx].reviewed = true;
    writeJSON(SIGNALS_FILE, signals);
  }
}

export function loadReviews(): SignalReview[] {
  return readJSON<SignalReview[]>(REVIEWS_FILE, []);
}

export function saveReview(review: SignalReview) {
  const reviews = loadReviews();
  const existing = reviews.findIndex((r) => r.id === review.id);
  if (existing >= 0) {
    reviews[existing] = review;
  } else {
    reviews.push(review);
  }
  writeJSON(REVIEWS_FILE, reviews);
}

export function getPendingSignals(): SavedSignal[] {
  const signals = loadSignals();
  const now = Date.now();
  const REVIEW_AFTER = 24 * 60 * 60 * 1000;
  return signals.filter((s) => !s.reviewed && now - s.timestamp >= REVIEW_AFTER);
}

export function generateSignalId(symbol: string, timestamp: number): string {
  return `${symbol}_${timestamp}`;
}
