/**
 * Multi-exchange symbol fetcher
 * Fetches all Spot trading pairs from Binance, OKX, Bybit, MEXC, KuCoin.
 * Results are cached in memory for CACHE_TTL ms.
 */

export interface ExchangeSymbol {
  symbol: string;   // normalised BASE/QUOTE e.g. "BTC/USDT"
  base: string;
  quote: string;
  exchanges: string[];
}

interface CacheEntry {
  data: ExchangeSymbol[];
  ts: number;
}

const CACHE_TTL = 6 * 60 * 60 * 1000; // 6 hours
let _cache: CacheEntry | null = null;

const FETCH_TIMEOUT = 12_000;

async function fetchWithTimeout(url: string, opts: RequestInit = {}): Promise<Response> {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), FETCH_TIMEOUT);
  try {
    return await fetch(url, { ...opts, signal: controller.signal });
  } finally {
    clearTimeout(id);
  }
}

async function fetchBinance(): Promise<ExchangeSymbol[]> {
  try {
    const res = await fetchWithTimeout("https://api.binance.com/api/v3/exchangeInfo");
    if (!res.ok) return [];
    const json = await res.json() as { symbols: { symbol: string; status: string; baseAsset: string; quoteAsset: string }[] };
    return json.symbols
      .filter((s) => s.status === "TRADING")
      .map((s) => ({ symbol: `${s.baseAsset}/${s.quoteAsset}`, base: s.baseAsset, quote: s.quoteAsset, exchanges: ["Binance"] }));
  } catch {
    console.error("[exchanges] Binance fetch failed");
    return [];
  }
}

async function fetchOKX(): Promise<ExchangeSymbol[]> {
  try {
    const res = await fetchWithTimeout("https://www.okx.com/api/v5/public/instruments?instType=SPOT");
    if (!res.ok) return [];
    const json = await res.json() as { data: { instId: string; state: string; baseCcy: string; quoteCcy: string }[] };
    return (json.data || [])
      .filter((s) => s.state === "live")
      .map((s) => ({ symbol: `${s.baseCcy}/${s.quoteCcy}`, base: s.baseCcy, quote: s.quoteCcy, exchanges: ["OKX"] }));
  } catch {
    console.error("[exchanges] OKX fetch failed");
    return [];
  }
}

async function fetchBybit(): Promise<ExchangeSymbol[]> {
  try {
    const res = await fetchWithTimeout("https://api.bybit.com/v5/market/instruments-info?category=spot&limit=1000");
    if (!res.ok) return [];
    const json = await res.json() as { result: { list: { symbol: string; status: string; baseCoin: string; quoteCoin: string }[] } };
    return (json.result?.list || [])
      .filter((s) => s.status === "Trading")
      .map((s) => ({ symbol: `${s.baseCoin}/${s.quoteCoin}`, base: s.baseCoin, quote: s.quoteCoin, exchanges: ["Bybit"] }));
  } catch {
    console.error("[exchanges] Bybit fetch failed");
    return [];
  }
}

async function fetchMEXC(): Promise<ExchangeSymbol[]> {
  try {
    const res = await fetchWithTimeout("https://api.mexc.com/api/v3/exchangeInfo");
    if (!res.ok) return [];
    const json = await res.json() as { symbols: { symbol: string; status: string; baseAsset: string; quoteAsset: string }[] };
    return (json.symbols || [])
      .filter((s) => s.status === "ENABLED")
      .map((s) => ({ symbol: `${s.baseAsset}/${s.quoteAsset}`, base: s.baseAsset, quote: s.quoteAsset, exchanges: ["MEXC"] }));
  } catch {
    console.error("[exchanges] MEXC fetch failed");
    return [];
  }
}

async function fetchKuCoin(): Promise<ExchangeSymbol[]> {
  try {
    const res = await fetchWithTimeout("https://api.kucoin.com/api/v1/symbols");
    if (!res.ok) return [];
    const json = await res.json() as { data: { symbol: string; enableTrading: boolean; baseCurrency: string; quoteCurrency: string }[] };
    return (json.data || [])
      .filter((s) => s.enableTrading)
      .map((s) => ({ symbol: `${s.baseCurrency}/${s.quoteCurrency}`, base: s.baseCurrency, quote: s.quoteCurrency, exchanges: ["KuCoin"] }));
  } catch {
    console.error("[exchanges] KuCoin fetch failed");
    return [];
  }
}

/** Fetch all symbols from all exchanges, merge & deduplicate. Cached for 6h. */
export async function getAllExchangeSymbols(): Promise<ExchangeSymbol[]> {
  if (_cache && Date.now() - _cache.ts < CACHE_TTL) return _cache.data;

  const [binance, okx, bybit, mexc, kucoin] = await Promise.all([
    fetchBinance(),
    fetchOKX(),
    fetchBybit(),
    fetchMEXC(),
    fetchKuCoin(),
  ]);

  const all = [...binance, ...okx, ...bybit, ...mexc, ...kucoin];

  // Merge duplicates — accumulate exchange list per symbol
  const map = new Map<string, ExchangeSymbol>();
  for (const item of all) {
    const key = item.symbol.toUpperCase();
    const existing = map.get(key);
    if (existing) {
      existing.exchanges = [...new Set([...existing.exchanges, ...item.exchanges])];
    } else {
      map.set(key, { ...item, symbol: key });
    }
  }

  const data = Array.from(map.values()).sort((a, b) => a.symbol.localeCompare(b.symbol));
  _cache = { data, ts: Date.now() };
  console.log(`[exchanges] Cached ${data.length} symbols from ${[binance, okx, bybit, mexc, kucoin].map((a, i) => `${["Binance","OKX","Bybit","MEXC","KuCoin"][i]}:${a.length}`).join(", ")}`);
  return data;
}

export function getCachedSymbols(): ExchangeSymbol[] {
  return _cache?.data ?? [];
}

export function getCacheAge(): number | null {
  return _cache ? Math.round((Date.now() - _cache.ts) / 1000) : null;
}

/** Warm the cache on startup without blocking */
export function warmExchangeCache(): void {
  getAllExchangeSymbols().catch((err) => console.error("[exchanges] Warm cache failed:", err));
}
