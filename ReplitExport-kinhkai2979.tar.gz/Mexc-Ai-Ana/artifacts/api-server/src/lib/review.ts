import { getKlines, getFuturesTicker } from "./mexc";
import { calcEMA, calcRSI, calcMACD, determineTrend } from "./indicators";
import type { SavedSignal, SignalReview } from "./storage";

function generateReflection(
  symbol: string,
  direction: string,
  outcome: string,
  directionCorrect: boolean,
  tp1Reached: boolean,
  tp2Reached: boolean,
  slHit: boolean,
  priceChangePct: number,
  entryPrice: number,
  currentPrice: number
): string {
  const dir = direction === "LONG" ? "mua (LONG)" : "bán (SHORT)";

  if (tp2Reached) {
    return `Phân tích ${symbol} theo hướng ${dir} đã thành công xuất sắc! TP2 đã được chạm — mức lợi nhuận tối đa đã đạt được. Giá đã di chuyển ${Math.abs(priceChangePct).toFixed(2)}% theo đúng dự đoán từ vùng vào lệnh ${entryPrice.toFixed(6)} đến ${currentPrice.toFixed(6)}. Phân tích kỹ thuật đa khung thời gian đã xác nhận xu hướng chính xác.`;
  }
  if (tp1Reached) {
    return `Phân tích ${symbol} theo hướng ${dir} đã thành công — TP1 đã được chạm với mức lợi nhuận hợp lý. Giá di chuyển ${Math.abs(priceChangePct).toFixed(2)}% đúng hướng dự đoán. Tuy TP2 chưa đạt được, đây vẫn là một giao dịch có lãi và xác nhận tính đúng đắn của phân tích ban đầu.`;
  }
  if (slHit) {
    return `Phân tích ${symbol} theo hướng ${dir} đã không chính xác — Stop Loss đã bị chạm. Giá di chuyển ngược chiều dự đoán ${Math.abs(priceChangePct).toFixed(2)}%. Đây là bài học quan trọng về việc thị trường không phải lúc nào cũng đi theo tín hiệu kỹ thuật, và việc đặt stop loss là điều cần thiết để bảo vệ vốn.`;
  }
  if (directionCorrect) {
    return `Phân tích ${symbol} theo hướng ${dir} đúng chiều — giá đã di chuyển ${Math.abs(priceChangePct).toFixed(2)}% theo hướng dự đoán từ ${entryPrice.toFixed(6)} đến ${currentPrice.toFixed(6)}, nhưng chưa chạm các mức TP. Tín hiệu ban đầu vẫn còn hiệu lực, nhà đầu tư có thể tiếp tục theo dõi.`;
  }
  return `Phân tích ${symbol} theo hướng ${dir} chưa chính xác trong giai đoạn này — giá đã di chuyển ${Math.abs(priceChangePct).toFixed(2)}% ngược chiều dự đoán từ ${entryPrice.toFixed(6)} đến ${currentPrice.toFixed(6)}. Cần xem lại các yếu tố thị trường và điều chỉnh chiến lược.`;
}

function generateWhatChanged(
  symbol: string,
  originalTrendH1: string,
  originalTrendH4: string,
  currentTrendH1: string,
  currentTrendH4: string,
  priceChangePct: number
): string {
  const trendVi: Record<string, string> = {
    Uptrend: "Xu hướng Tăng",
    Downtrend: "Xu hướng Giảm",
    Sideways: "Đi Ngang",
  };

  const h1Changed = originalTrendH1 !== currentTrendH1;
  const h4Changed = originalTrendH4 !== currentTrendH4;

  if (h1Changed && h4Changed) {
    return `Thị trường ${symbol} đã thay đổi đáng kể. Xu hướng H1 chuyển từ ${trendVi[originalTrendH1] || originalTrendH1} sang ${trendVi[currentTrendH1] || currentTrendH1}. Xu hướng H4 chuyển từ ${trendVi[originalTrendH4] || originalTrendH4} sang ${trendVi[currentTrendH4] || currentTrendH4}. Giá biến động ${Math.abs(priceChangePct).toFixed(2)}% trong 24 giờ qua.`;
  }
  if (h1Changed) {
    return `Xu hướng ngắn hạn (H1) của ${symbol} đã thay đổi từ ${trendVi[originalTrendH1] || originalTrendH1} sang ${trendVi[currentTrendH1] || currentTrendH1}. Xu hướng dài hạn H4 vẫn duy trì ${trendVi[currentTrendH4] || currentTrendH4}. Có thể chỉ là biến động ngắn hạn tạm thời.`;
  }
  if (h4Changed) {
    return `Xu hướng trung hạn (H4) của ${symbol} đã chuyển từ ${trendVi[originalTrendH4] || originalTrendH4} sang ${trendVi[currentTrendH4] || currentTrendH4}. Đây là tín hiệu quan trọng cho thấy xu hướng chính đang thay đổi.`;
  }
  return `Các khung thời gian của ${symbol} vẫn duy trì xu hướng ban đầu (H1: ${trendVi[currentTrendH1] || currentTrendH1}, H4: ${trendVi[currentTrendH4] || currentTrendH4}). Giá biến động ${Math.abs(priceChangePct).toFixed(2)}% trong giai đoạn đánh giá.`;
}

function generateLesson(
  direction: string,
  outcome: string,
  confidence: number,
  tp1Reached: boolean,
  tp2Reached: boolean,
  slHit: boolean,
  directionCorrect: boolean
): string {
  if (tp2Reached) {
    return `Bài học: Khi tất cả các chỉ báo đồng thuận và điểm tín hiệu cao (${confidence}/100), chiến lược giữ đến TP2 mang lại kết quả tốt nhất. Tiếp tục áp dụng phương pháp phân tích đa khung thời gian trong các giao dịch tương lai.`;
  }
  if (tp1Reached) {
    return `Bài học: Chốt lời một phần tại TP1 là chiến lược an toàn. Với điểm tín hiệu ${confidence}/100, có thể để một phần vị thế chạy đến TP2 để tối đa hóa lợi nhuận. Quản lý vị thế linh hoạt là chìa khóa.`;
  }
  if (slHit) {
    if (confidence >= 80) {
      return `Bài học: Ngay cả với điểm tín hiệu cao (${confidence}/100), thị trường vẫn có thể đi ngược. Điều này nhắc nhở rằng không có hệ thống nào hoàn hảo 100%. Việc đặt stop loss và quản lý rủi ro là điều bắt buộc để bảo vệ vốn lâu dài.`;
    }
    return `Bài học: Với điểm tín hiệu ${confidence}/100, rủi ro của giao dịch này đã khá cao. Nên cân nhắc chỉ vào lệnh khi điểm tín hiệu đạt từ 75+ và tất cả điều kiện đều thỏa mãn. Quản lý kích thước vị thế (position sizing) cũng rất quan trọng.`;
  }
  if (directionCorrect) {
    return `Bài học: Hướng phân tích chính xác nhưng thị trường chưa đến các mức mục tiêu. Cần kiên nhẫn hơn và đặt mức TP phù hợp với biên độ biến động thực tế của cặp này. Theo dõi thêm để xem có cơ hội tiếp theo không.`;
  }
  return `Bài học: Lần này phân tích chưa chính xác. Cần xem lại các điều kiện vào lệnh và đảm bảo tất cả khung thời gian đều đồng thuận trước khi quyết định. Đây là phần tất yếu của giao dịch — không có hệ thống nào thắng 100%.`;
}

function determineOutcome(
  direction: string,
  entryPrice: number,
  currentPrice: number,
  stopLoss: number,
  takeProfit1: number,
  takeProfit2: number,
  highInPeriod: number,
  lowInPeriod: number
): {
  outcome: string;
  directionCorrect: boolean;
  tp1Reached: boolean;
  tp2Reached: boolean;
  slHit: boolean;
} {
  let tp1Reached = false;
  let tp2Reached = false;
  let slHit = false;
  let directionCorrect = false;

  if (direction === "LONG") {
    slHit = lowInPeriod <= stopLoss;
    tp1Reached = highInPeriod >= takeProfit1;
    tp2Reached = highInPeriod >= takeProfit2;
    directionCorrect = currentPrice > entryPrice;
  } else {
    slHit = highInPeriod >= stopLoss;
    tp1Reached = lowInPeriod <= takeProfit1;
    tp2Reached = lowInPeriod <= takeProfit2;
    directionCorrect = currentPrice < entryPrice;
  }

  let outcome: string;
  if (tp2Reached && !slHit) {
    outcome = "TP2_HIT";
    tp1Reached = true;
  } else if (tp1Reached && !slHit) {
    outcome = "TP1_HIT";
  } else if (slHit) {
    outcome = "SL_HIT";
    tp1Reached = false;
    tp2Reached = false;
  } else if (directionCorrect) {
    outcome = "CORRECT_DIRECTION";
  } else {
    outcome = "WRONG_DIRECTION";
  }

  return { outcome, directionCorrect, tp1Reached, tp2Reached, slHit };
}

export async function reviewSignal(signal: SavedSignal): Promise<SignalReview | null> {
  try {
    const mexcSymbol = signal.symbol.replace("/", "_");
    const [klinesH1, klinesH4, ticker] = await Promise.all([
      getKlines(mexcSymbol, "Min60", 30),
      getKlines(mexcSymbol, "Hour4", 30),
      getFuturesTicker(mexcSymbol),
    ]);

    if (!ticker || !klinesH1.length) return null;

    const currentPrice = ticker.lastPrice;

    const highInPeriod = klinesH1.length > 0 ? Math.max(...klinesH1.map((k) => k.high)) : currentPrice;
    const lowInPeriod = klinesH1.length > 0 ? Math.min(...klinesH1.map((k) => k.low)) : currentPrice;

    const closesH1 = klinesH1.map((k) => k.close);
    const ema20H1Arr = calcEMA(closesH1, 20);
    const ema50H1Arr = calcEMA(closesH1, 50);
    const ema20H1 = ema20H1Arr[ema20H1Arr.length - 1] || signal.ema20;
    const ema50H1 = ema50H1Arr[ema50H1Arr.length - 1] || signal.ema50;
    const currentTrendH1 = determineTrend(closesH1, ema20H1, ema50H1);

    const closesH4 = klinesH4.length >= 10 ? klinesH4.map((k) => k.close) : closesH1;
    const ema20H4Arr = calcEMA(closesH4, 20);
    const ema50H4Arr = calcEMA(closesH4, 50);
    const ema20H4 = ema20H4Arr[ema20H4Arr.length - 1] || signal.ema20;
    const ema50H4 = ema50H4Arr[ema50H4Arr.length - 1] || signal.ema50;
    const currentTrendH4 = determineTrend(closesH4, ema20H4, ema50H4);

    const priceChangePct = ((currentPrice - signal.entryPrice) / signal.entryPrice) * 100;

    const { outcome, directionCorrect, tp1Reached, tp2Reached, slHit } = determineOutcome(
      signal.direction,
      signal.entryPrice,
      currentPrice,
      signal.stopLoss,
      signal.takeProfit1,
      signal.takeProfit2,
      highInPeriod,
      lowInPeriod
    );

    const stillValid =
      !slHit &&
      ((signal.direction === "LONG" && currentTrendH1 !== "Downtrend") ||
        (signal.direction === "SHORT" && currentTrendH1 !== "Uptrend"));

    const reflection = generateReflection(
      signal.symbol, signal.direction, outcome, directionCorrect,
      tp1Reached, tp2Reached, slHit, priceChangePct,
      signal.entryPrice, currentPrice
    );
    const whatChanged = generateWhatChanged(
      signal.symbol, signal.trendH1, signal.trendH4,
      currentTrendH1, currentTrendH4, priceChangePct
    );
    const lesson = generateLesson(
      signal.direction, outcome, signal.confidence,
      tp1Reached, tp2Reached, slHit, directionCorrect
    );

    return {
      id: `review_${signal.id}`,
      signalId: signal.id,
      symbol: signal.symbol,
      reviewedAt: Date.now(),
      originalDirection: signal.direction,
      entryPrice: signal.entryPrice,
      stopLoss: signal.stopLoss,
      takeProfit1: signal.takeProfit1,
      takeProfit2: signal.takeProfit2,
      confidence: signal.confidence,
      currentPrice,
      outcome,
      directionCorrect,
      tp1Reached,
      tp2Reached,
      slHit,
      currentTrendH1,
      currentTrendH4,
      stillValid,
      reflection,
      whatChanged,
      lesson,
      priceChangePct: Math.round(priceChangePct * 100) / 100,
      signalTimestamp: signal.timestamp,
    };
  } catch (err) {
    console.error(`Review error for ${signal.symbol}:`, err);
    return null;
  }
}
