export function explainRSI(rsi: number): string {
  if (rsi >= 80) return `RSI(14) = ${rsi.toFixed(1)} — vùng quá mua cực đoan. Nguy cơ đảo chiều giảm rất cao, tránh vào LONG mới.`;
  if (rsi >= 70) return `RSI(14) = ${rsi.toFixed(1)} — vùng quá mua. Áp lực chốt lời đang tăng, cần thận trọng với LONG.`;
  if (rsi <= 20) return `RSI(14) = ${rsi.toFixed(1)} — vùng quá bán cực đoan. Có thể xuất hiện sóng phục hồi kỹ thuật mạnh.`;
  if (rsi <= 30) return `RSI(14) = ${rsi.toFixed(1)} — vùng quá bán. Áp lực mua đang tích lũy, tiềm năng bật tăng.`;
  if (rsi >= 55 && rsi < 70) return `RSI(14) = ${rsi.toFixed(1)} — vùng tăng động lực. Xu hướng tăng đang có lực, chưa quá mua.`;
  if (rsi >= 45 && rsi < 55) return `RSI(14) = ${rsi.toFixed(1)} — vùng trung tính. Thị trường cân bằng, cần xác nhận thêm.`;
  if (rsi > 30 && rsi < 45) return `RSI(14) = ${rsi.toFixed(1)} — vùng yếu. Lực giảm đang chiếm ưu thế nhẹ.`;
  return `RSI(14) = ${rsi.toFixed(1)}`;
}

export function explainEMA(price: number, ema20: number, ema50: number): string {
  if (ema20 > ema50 && price > ema20) {
    const pct = (((ema20 - ema50) / ema50) * 100).toFixed(2);
    return `EMA20 (${ema20.toFixed(4)}) trên EMA50 (${ema50.toFixed(4)}) khoảng ${pct}% — Golden Cross. Giá trên cả hai đường EMA, lực mua chiếm ưu thế.`;
  }
  if (ema20 < ema50 && price < ema20) {
    const pct = (((ema50 - ema20) / ema50) * 100).toFixed(2);
    return `EMA20 (${ema20.toFixed(4)}) dưới EMA50 (${ema50.toFixed(4)}) khoảng ${pct}% — Death Cross. Giá dưới cả hai đường EMA, lực bán chiếm ưu thế.`;
  }
  if (ema20 > ema50) {
    return `EMA20 (${ema20.toFixed(4)}) trên EMA50 (${ema50.toFixed(4)}) — xu hướng tăng trung hạn. Giá đang kiểm tra vùng EMA20, theo dõi phản ứng.`;
  }
  return `EMA20 (${ema20.toFixed(4)}) dưới EMA50 (${ema50.toFixed(4)}) — xu hướng giảm trung hạn. Giá kháng cự tại EMA20, áp lực bán còn đó.`;
}

export function explainMACD(macdValue: number, signal: number, histogram: number): string {
  if (macdValue > signal && histogram > 0) {
    if (histogram > Math.abs(macdValue) * 0.1) {
      return `MACD (${macdValue.toFixed(4)}) trên Signal (${signal.toFixed(4)}) — bullish crossover mạnh. Histogram dương mở rộng (${histogram.toFixed(4)}), đà tăng đang gia tăng.`;
    }
    return `MACD (${macdValue.toFixed(4)}) trên Signal (${signal.toFixed(4)}) — tín hiệu tăng. Histogram dương nhưng còn nhỏ, đà tăng đang hình thành.`;
  }
  if (macdValue < signal && histogram < 0) {
    return `MACD (${macdValue.toFixed(4)}) dưới Signal (${signal.toFixed(4)}) — tín hiệu giảm. Histogram âm (${histogram.toFixed(4)}), áp lực bán đang tăng.`;
  }
  return `MACD đang trong vùng giao thoa — tín hiệu chưa rõ. Chờ histogram xác nhận chiều hướng.`;
}

export function explainVolume(volumeChange: number, volume24h: number): string {
  if (volumeChange > 50) return `Khối lượng tăng đột biến ${volumeChange.toFixed(1)}% — xác nhận tín hiệu rất mạnh. Dòng tiền lớn đang vào thị trường.`;
  if (volumeChange > 20) return `Khối lượng tăng ${volumeChange.toFixed(1)}% — xác nhận tốt. Có sự tham gia đáng kể ủng hộ xu hướng hiện tại.`;
  if (volumeChange < -20) return `Khối lượng giảm ${Math.abs(volumeChange).toFixed(1)}% — tín hiệu thiếu xác nhận. Xu hướng hiện tại có thể không bền vững.`;
  return `Khối lượng ổn định, thay đổi ${volumeChange.toFixed(1)}%. Thị trường đang tích lũy, chờ tín hiệu đột phá.`;
}

export function explainBollingerBands(
  price: number,
  upper: number,
  lower: number,
  width: number,
  percentB: number,
): string {
  const pct = (percentB * 100).toFixed(0);
  if (percentB > 1.0) return `Giá ($${price.toFixed(4)}) vượt dải BB trên ($${upper.toFixed(4)}) — breakout tăng mạnh. Cẩn thận với tín hiệu quá mua cực đoan.`;
  if (percentB < 0) return `Giá ($${price.toFixed(4)}) phá dải BB dưới ($${lower.toFixed(4)}) — breakout giảm mạnh. Cẩn thận với tín hiệu quá bán cực đoan.`;
  if (width < 0.02) return `Dải Bollinger đang nén rất mạnh (width=${(width * 100).toFixed(2)}%) — thị trường sắp bùng nổ. Chú ý breakout theo chiều nào.`;
  if (width < 0.04) return `Dải Bollinger hẹp (width=${(width * 100).toFixed(2)}%) — giai đoạn tích lũy, chuẩn bị cho biến động lớn.`;
  if (percentB > 0.8) return `Giá ở ${pct}% trong dải BB — áp sát dải trên, đà tăng mạnh nhưng theo dõi phân kỳ.`;
  if (percentB < 0.2) return `Giá ở ${pct}% trong dải BB — áp sát dải dưới, tiềm năng hồi phục.`;
  return `Giá ở ${pct}% trong dải BB — vùng trung tâm, thị trường cân bằng.`;
}

export function explainATR(atr: number, price: number): string {
  const atrPct = price > 0 ? (atr / price) * 100 : 0;
  if (atrPct > 5) return `ATR = $${atr.toFixed(4)} (${atrPct.toFixed(2)}% giá) — biến động cực cao. Rủi ro lớn, mở rộng SL/TP so với bình thường.`;
  if (atrPct > 3) return `ATR = $${atr.toFixed(4)} (${atrPct.toFixed(2)}% giá) — biến động cao. Thị trường đang năng động, phù hợp cho swing trade.`;
  if (atrPct > 1) return `ATR = $${atr.toFixed(4)} (${atrPct.toFixed(2)}% giá) — biến động bình thường. Điều kiện giao dịch lý tưởng.`;
  return `ATR = $${atr.toFixed(4)} (${atrPct.toFixed(2)}% giá) — biến động thấp. Thị trường ít biến động, TP/SL có thể cần điều chỉnh nhỏ hơn.`;
}

export function explainTrend(trendH1: string, trendH4: string, symbol: string): string {
  const trendViMap: Record<string, string> = {
    Uptrend: "Xu hướng Tăng",
    Downtrend: "Xu hướng Giảm",
    Sideways: "Đi Ngang",
  };
  const h1Vi = trendViMap[trendH1] || trendH1;
  const h4Vi = trendViMap[trendH4] || trendH4;

  if (trendH1 === "Uptrend" && trendH4 === "Uptrend") {
    return `H1 (${h1Vi}) và H4 (${h4Vi}) đồng thuận tăng — tín hiệu đa khung rất mạnh. Điều kiện lý tưởng để tìm cơ hội LONG.`;
  }
  if (trendH1 === "Downtrend" && trendH4 === "Downtrend") {
    return `H1 (${h1Vi}) và H4 (${h4Vi}) đồng thuận giảm — tín hiệu đa khung mạnh theo chiều bán. Ưu tiên tìm cơ hội SHORT.`;
  }
  if (trendH4 === "Uptrend" && trendH1 !== "Uptrend") {
    return `H4 đang ${h4Vi} nhưng H1 đang ${h1Vi}. Xu hướng lớn vẫn tăng, ngắn hạn đang điều chỉnh — cơ hội mua pullback.`;
  }
  if (trendH4 === "Downtrend" && trendH1 !== "Downtrend") {
    return `H4 đang ${h4Vi} nhưng H1 đang ${h1Vi}. Xu hướng lớn vẫn giảm, hồi phục ngắn hạn — cơ hội SHORT khi đà hồi phục kết thúc.`;
  }
  return `H1 (${h1Vi}) và H4 (${h4Vi}) chưa đồng thuận — tín hiệu đa khung yếu. Chờ thêm xác nhận.`;
}

export function generateTradingSuggestionReasoning(
  symbol: string,
  direction: string,
  score: number,
  rsi: number,
  ema20: number,
  ema50: number,
  macdValue: number,
  macdSignal: number,
  trendH1: string,
  trendH4: string,
  support: number,
  resistance: number,
): string {
  if (direction === "HOLD") {
    return `Chưa có tín hiệu đủ mạnh cho ${symbol} (điểm: ${score}/100). Thị trường đang trong giai đoạn thiếu xác nhận. Nên chờ đợi khi có ít nhất 2–3 chỉ báo đồng thuận rõ ràng trước khi vào lệnh. Vùng hỗ trợ: ${support.toFixed(4)} | Vùng kháng cự: ${resistance.toFixed(4)}.`;
  }

  const dir = direction === "LONG" ? "mua (LONG)" : "bán (SHORT)";
  const scoreDesc = score >= 85 ? "rất cao" : score >= 75 ? "cao" : score >= 65 ? "trung bình" : "thấp";
  const trendAgree = trendH1 === trendH4 ? "đồng thuận" : "chưa đồng thuận";

  return `Đề xuất vào lệnh ${dir} cho ${symbol} — điểm tín hiệu ${score}/100 (${scoreDesc}). ` +
    `${ema20 > ema50 ? "EMA20 trên EMA50 (xu hướng tăng)." : "EMA20 dưới EMA50 (xu hướng giảm)."} ` +
    `MACD ${macdValue > macdSignal ? "vừa cắt lên Signal (bullish)" : "đang dưới Signal (bearish)"}. ` +
    `RSI(14) = ${rsi.toFixed(1)}${rsi >= 45 && rsi <= 65 ? " (vùng lý tưởng)" : rsi > 65 ? " (tiếp cận quá mua)" : " (vùng quá bán)"}. ` +
    `Xu hướng H1 & H4 ${trendAgree}. ` +
    `Hỗ trợ: ${support.toFixed(4)} | Kháng cự: ${resistance.toFixed(4)}. ` +
    `Lưu ý: Đây là phân tích kỹ thuật tự động, không phải lời khuyên đầu tư. Luôn đặt stop loss.`;
}
