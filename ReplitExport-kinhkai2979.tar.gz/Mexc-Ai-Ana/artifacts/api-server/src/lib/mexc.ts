const MEXC_FUTURES_BASE = "https://contract.mexc.com/api/v1/contract";
const MEXC_SPOT_BASE = "https://api.mexc.com/api/v3";

export interface FuturesTicker {
  symbol: string;
  lastPrice: number;
  bid1: number;
  ask1: number;
  volume24: number;
  amount24: number;
  priceChangeRate: number;
  riseFallRate: number;
  riseFallValue: number;
  indexPrice: number;
  fairPrice: number;
  fundingRate: number;
  maxBidPrice: number;
  minAskPrice: number;
  timestamp: number;
}

export interface KlineData {
  time: number;
  open: number;
  close: number;
  high: number;
  low: number;
  vol: number;
  amount: number;
}

export async function getFuturesTickers(): Promise<FuturesTicker[]> {
  const res = await fetch(`${MEXC_FUTURES_BASE}/ticker`);
  if (!res.ok) throw new Error(`MEXC ticker error: ${res.status}`);
  const json = await res.json();
  if (!json.success) throw new Error("MEXC ticker failed");
  return json.data as FuturesTicker[];
}

export async function getFuturesTicker(symbol: string): Promise<FuturesTicker | null> {
  const res = await fetch(`${MEXC_FUTURES_BASE}/ticker?symbol=${symbol}`);
  if (!res.ok) return null;
  const json = await res.json();
  if (!json.success) return null;
  return Array.isArray(json.data) ? json.data[0] : json.data;
}

export async function getKlines(symbol: string, interval: string, limit: number = 100): Promise<KlineData[]> {
  const end = Math.floor(Date.now() / 1000);
  const intervalSeconds: Record<string, number> = {
    Min1: 60, Min5: 300, Min15: 900, Min30: 1800,
    Min60: 3600, Hour4: 14400, Day1: 86400,
  };
  const secs = intervalSeconds[interval] || 3600;
  const start = end - secs * limit;
  const url = `${MEXC_FUTURES_BASE}/kline/${symbol}?interval=${interval}&start=${start}&end=${end}`;
  const res = await fetch(url);
  if (!res.ok) return [];
  const json = await res.json();
  if (!json.success || !json.data) return [];
  const d = json.data;
  const times: number[] = d.time || [];
  const opens: number[] = d.open || [];
  const closes: number[] = d.close || [];
  const highs: number[] = d.high || [];
  const lows: number[] = d.low || [];
  const vols: number[] = d.vol || [];
  const amounts: number[] = d.amount || [];
  return times.map((t, i) => ({
    time: t, open: opens[i], close: closes[i],
    high: highs[i], low: lows[i], vol: vols[i], amount: amounts[i],
  }));
}

export async function getSpotPrice(symbol: string): Promise<{ price: number; change24h: number; volume24h: number } | null> {
  try {
    const res = await fetch(`${MEXC_SPOT_BASE}/ticker/24hr?symbol=${symbol}`);
    if (!res.ok) return null;
    const d = await res.json();
    return {
      price: parseFloat(d.lastPrice),
      change24h: parseFloat(d.priceChangePercent),
      volume24h: parseFloat(d.volume),
    };
  } catch {
    return null;
  }
}
