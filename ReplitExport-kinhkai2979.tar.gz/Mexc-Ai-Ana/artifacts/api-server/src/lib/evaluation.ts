/**
 * Evaluation engine — computes AI signal performance metrics
 * from existing reviews.json data without touching the live signal flow.
 */

import { loadReviews, loadSignals, type SignalReview } from "./storage";

export interface EvaluationSummary {
  totalSignals: number;
  totalReviewed: number;
  winRate: number;
  tp1Rate: number;
  tp2Rate: number;
  slRate: number;
  avgConfidence: number;
  avgPriceChange: number;
  correctSignals: number;
  wrongSignals: number;
  bestSymbols: { symbol: string; winRate: number; total: number }[];
  worstSymbols: { symbol: string; winRate: number; total: number }[];
  byDirection: {
    longStats: { wins: number; total: number; winRate: number };
    shortStats: { wins: number; total: number; winRate: number };
  };
  confidenceVsAccuracy: { bucket: string; winRate: number; count: number }[];
  updatedAt: number;
}

export interface HourlyEvaluationPoint {
  hour: number;       // 0–23 UTC hour of signal
  totalSignals: number;
  wins: number;
  losses: number;
  winRate: number;
  avgConfidence: number;
}

export interface DailyEvaluationPoint {
  date: string;       // "YYYY-MM-DD"
  totalSignals: number;
  wins: number;
  losses: number;
  winRate: number;
  avgConfidence: number;
  avgPriceChange: number;
}

function isWin(r: SignalReview): boolean {
  return r.tp1Reached || r.tp2Reached || (r.directionCorrect && !r.slHit);
}

function isLoss(r: SignalReview): boolean {
  return r.slHit || (!r.directionCorrect && !r.tp1Reached && !r.tp2Reached && r.outcome !== "STILL_ACTIVE");
}

export function computeEvaluationSummary(): EvaluationSummary {
  const signals = loadSignals();
  const reviews = loadReviews();
  const reviewed = reviews.filter((r) => r.outcome !== "STILL_ACTIVE");

  const totalSignals = signals.length;
  const totalReviewed = reviewed.length;

  if (totalReviewed === 0) {
    return {
      totalSignals, totalReviewed: 0,
      winRate: 0, tp1Rate: 0, tp2Rate: 0, slRate: 0,
      avgConfidence: 0, avgPriceChange: 0,
      correctSignals: 0, wrongSignals: 0,
      bestSymbols: [], worstSymbols: [],
      byDirection: {
        longStats:  { wins: 0, total: 0, winRate: 0 },
        shortStats: { wins: 0, total: 0, winRate: 0 },
      },
      confidenceVsAccuracy: [],
      updatedAt: Date.now(),
    };
  }

  const wins = reviewed.filter(isWin).length;
  const losses = reviewed.filter(isLoss).length;
  const tp1Count = reviewed.filter((r) => r.tp1Reached).length;
  const tp2Count = reviewed.filter((r) => r.tp2Reached).length;
  const slCount = reviewed.filter((r) => r.slHit).length;

  const avgConfidence = Math.round(reviewed.reduce((s, r) => s + r.confidence, 0) / totalReviewed);
  const avgPriceChange = parseFloat((reviewed.reduce((s, r) => s + r.priceChangePct, 0) / totalReviewed).toFixed(2));

  // By direction
  const longReviews  = reviewed.filter((r) => r.originalDirection === "LONG");
  const shortReviews = reviewed.filter((r) => r.originalDirection === "SHORT");

  // By symbol
  const symbolMap = new Map<string, { wins: number; total: number }>();
  for (const r of reviewed) {
    const e = symbolMap.get(r.symbol) || { wins: 0, total: 0 };
    symbolMap.set(r.symbol, { wins: e.wins + (isWin(r) ? 1 : 0), total: e.total + 1 });
  }
  const symbolArr = Array.from(symbolMap.entries())
    .map(([symbol, { wins: w, total: t }]) => ({ symbol, winRate: Math.round((w / t) * 100), total: t }))
    .filter((s) => s.total >= 2);

  const bestSymbols  = [...symbolArr].sort((a, b) => b.winRate - a.winRate).slice(0, 5);
  const worstSymbols = [...symbolArr].sort((a, b) => a.winRate - b.winRate).slice(0, 5);

  // Confidence buckets: 50-65, 65-75, 75-85, 85-100
  const buckets = [
    { label: "50–65", min: 50, max: 65 },
    { label: "65–75", min: 65, max: 75 },
    { label: "75–85", min: 75, max: 85 },
    { label: "85–100", min: 85, max: 101 },
  ];
  const confidenceVsAccuracy = buckets.map(({ label, min, max }) => {
    const bucket = reviewed.filter((r) => r.confidence >= min && r.confidence < max);
    const bWins  = bucket.filter(isWin).length;
    return { bucket: label, winRate: bucket.length > 0 ? Math.round((bWins / bucket.length) * 100) : 0, count: bucket.length };
  });

  return {
    totalSignals,
    totalReviewed,
    winRate: Math.round((wins / totalReviewed) * 100),
    tp1Rate: Math.round((tp1Count / totalReviewed) * 100),
    tp2Rate: Math.round((tp2Count / totalReviewed) * 100),
    slRate:  Math.round((slCount / totalReviewed) * 100),
    avgConfidence,
    avgPriceChange,
    correctSignals: wins,
    wrongSignals: losses,
    bestSymbols,
    worstSymbols,
    byDirection: {
      longStats:  { wins: longReviews.filter(isWin).length,  total: longReviews.length,  winRate: longReviews.length  > 0 ? Math.round((longReviews.filter(isWin).length  / longReviews.length)  * 100) : 0 },
      shortStats: { wins: shortReviews.filter(isWin).length, total: shortReviews.length, winRate: shortReviews.length > 0 ? Math.round((shortReviews.filter(isWin).length / shortReviews.length) * 100) : 0 },
    },
    confidenceVsAccuracy,
    updatedAt: Date.now(),
  };
}

export function computeHourlyEvaluation(): HourlyEvaluationPoint[] {
  const reviews = loadReviews().filter((r) => r.outcome !== "STILL_ACTIVE");

  const hourMap = new Map<number, { wins: number; losses: number; total: number; confSum: number }>();
  for (let h = 0; h < 24; h++) hourMap.set(h, { wins: 0, losses: 0, total: 0, confSum: 0 });

  for (const r of reviews) {
    const hour = new Date(r.signalTimestamp).getUTCHours();
    const entry = hourMap.get(hour)!;
    entry.total++;
    entry.confSum += r.confidence;
    if (isWin(r)) entry.wins++;
    if (isLoss(r)) entry.losses++;
  }

  return Array.from(hourMap.entries()).map(([hour, { wins, losses, total, confSum }]) => ({
    hour,
    totalSignals: total,
    wins,
    losses,
    winRate: total > 0 ? Math.round((wins / total) * 100) : 0,
    avgConfidence: total > 0 ? Math.round(confSum / total) : 0,
  }));
}

export function computeDailyEvaluation(days = 30): DailyEvaluationPoint[] {
  const reviews = loadReviews().filter((r) => r.outcome !== "STILL_ACTIVE");
  const cutoff  = Date.now() - days * 24 * 60 * 60 * 1000;

  const dayMap = new Map<string, { wins: number; losses: number; total: number; confSum: number; pcSum: number }>();

  for (const r of reviews) {
    if (r.signalTimestamp < cutoff) continue;
    const d = new Date(r.signalTimestamp).toISOString().slice(0, 10);
    const e = dayMap.get(d) || { wins: 0, losses: 0, total: 0, confSum: 0, pcSum: 0 };
    e.total++;
    e.confSum += r.confidence;
    e.pcSum   += r.priceChangePct;
    if (isWin(r))  e.wins++;
    if (isLoss(r)) e.losses++;
    dayMap.set(d, e);
  }

  return Array.from(dayMap.entries())
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, { wins, losses, total, confSum, pcSum }]) => ({
      date,
      totalSignals: total,
      wins,
      losses,
      winRate: total > 0 ? Math.round((wins / total) * 100) : 0,
      avgConfidence: total > 0 ? Math.round(confSum / total) : 0,
      avgPriceChange: total > 0 ? parseFloat((pcSum / total).toFixed(2)) : 0,
    }));
}
