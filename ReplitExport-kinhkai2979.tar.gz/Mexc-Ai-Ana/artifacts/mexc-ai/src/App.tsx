import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { Layout } from "@/components/Layout";

import Dashboard from "@/pages/Dashboard";
import Scanner from "@/pages/Scanner";
import CoinDetail from "@/pages/CoinDetail";
import News from "@/pages/News";
import Summary from "@/pages/Summary";
import Alerts from "@/pages/Alerts";
import Review from "@/pages/Review";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: false,
    },
  },
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/scanner" component={Scanner} />
        <Route path="/coin/:symbol" component={CoinDetail} />
        <Route path="/coins/:symbol" component={CoinDetail} />
        <Route path="/news" component={News} />
        <Route path="/summary" component={Summary} />
        <Route path="/alerts" component={Alerts} />
        <Route path="/review" component={Review} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;