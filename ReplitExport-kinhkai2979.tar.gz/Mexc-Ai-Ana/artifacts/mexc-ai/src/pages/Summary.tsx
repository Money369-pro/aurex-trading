import { useGetMarketSummary, getGetMarketSummaryQueryKey } from "@workspace/api-client-react";
import { Brain, TrendingUp, TrendingDown, ShieldAlert, Sparkles } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

export default function Summary() {
  const { data, isLoading } = useGetMarketSummary({
    query: {
      queryKey: getGetMarketSummaryQueryKey()
    }
  });

  if (isLoading || !data) {
    return (
      <div className="p-4 space-y-6">
        <Skeleton className="h-8 w-1/2 mb-4" />
        <Skeleton className="h-24 w-full" />
        <div className="grid grid-cols-2 gap-4">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-32 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col space-y-6 p-4 pb-12 animate-in fade-in duration-300">
      <header className="flex items-center gap-2">
        <Brain className="w-6 h-6 text-primary" />
        <h1 className="text-xl font-bold tracking-tight text-white">AI Phân Tích Nhận Định</h1>
      </header>

      <section className="bg-primary/5 border border-primary/20 rounded-xl p-4">
        <p className="text-sm leading-relaxed text-white/90">
          {data.overview}
        </p>
        <div className="text-[10px] text-muted-foreground mt-3 text-right">
          Cập nhật: {new Date(data.generatedAt).toLocaleString("vi-VN")}
        </div>
      </section>

      <div className="grid grid-cols-1 gap-4">
        <div className="bg-green-500/5 border border-green-500/20 rounded-xl p-4">
          <h2 className="text-green-500 font-bold text-sm mb-2 flex items-center gap-1">
            <TrendingUp className="w-4 h-4" /> Kịch Bản Tăng Giá (Bullish)
          </h2>
          <p className="text-xs text-muted-foreground leading-relaxed">
            {data.bullishScenario}
          </p>
        </div>

        <div className="bg-red-500/5 border border-red-500/20 rounded-xl p-4">
          <h2 className="text-red-500 font-bold text-sm mb-2 flex items-center gap-1">
            <TrendingDown className="w-4 h-4" /> Kịch Bản Giảm Giá (Bearish)
          </h2>
          <p className="text-xs text-muted-foreground leading-relaxed">
            {data.bearishScenario}
          </p>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <h2 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-yellow-500" /> Cơ Hội Hàng Đầu
          </h2>
          <ul className="space-y-2">
            {data.topOpportunities.map((opp, idx) => (
              <li key={idx} className="bg-card border border-border p-3 rounded-lg text-xs text-muted-foreground">
                {opp}
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h2 className="text-sm font-bold text-white mb-2 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-orange-500" /> Rủi Ro Chính
          </h2>
          <ul className="space-y-2">
            {data.keyRisks.map((risk, idx) => (
              <li key={idx} className="bg-card border border-border p-3 rounded-lg text-xs text-muted-foreground">
                {risk}
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}