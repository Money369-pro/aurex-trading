import { useGetNews, getGetNewsQueryKey } from "@workspace/api-client-react";
import { ExternalLink, Calendar } from "lucide-react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

export default function News() {
  const { data, isLoading } = useGetNews({
    query: {
      queryKey: getGetNewsQueryKey()
    }
  });

  if (isLoading || !data) {
    return (
      <div className="p-4 space-y-4">
        <Skeleton className="h-8 w-1/3 mb-6" />
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-32 w-full rounded-xl" />
        ))}
      </div>
    );
  }

  return (
    <div className="flex flex-col space-y-4 p-4 pb-10">
      <header>
        <h1 className="text-xl font-bold tracking-tight text-white">Tin Tức Thị Trường</h1>
      </header>

      <div className="space-y-4">
        {data.articles.map((article) => (
          <a
            key={article.id}
            href={article.url}
            target="_blank"
            rel="noopener noreferrer"
            className="block bg-card border border-border hover:bg-white/5 transition-colors rounded-xl p-4 group"
          >
            <div className="flex justify-between items-start gap-4 mb-2">
              <h2 className="font-bold text-white text-sm leading-snug group-hover:text-primary transition-colors">
                {article.title}
              </h2>
              <div
                className={cn(
                  "shrink-0 text-[10px] font-bold px-1.5 py-0.5 rounded",
                  article.impact === "Tích cực" && "bg-green-500/10 text-green-500",
                  article.impact === "Tiêu cực" && "bg-red-500/10 text-red-500",
                  article.impact === "Trung lập" && "bg-white/10 text-muted-foreground"
                )}
              >
                {article.impact}
              </div>
            </div>
            
            <p className="text-xs text-muted-foreground line-clamp-2 mb-3">
              {article.summary}
            </p>
            
            <div className="bg-black/20 rounded p-2 text-[10px] mb-3">
              <span className="text-white/70 font-semibold">Tác động:</span> <span className="text-muted-foreground">{article.whyItMatters}</span>
            </div>

            <div className="flex items-center justify-between text-[10px] text-muted-foreground">
              <div className="flex items-center gap-2">
                <span className="font-medium text-white/50">{article.source}</span>
                <span>•</span>
                <span className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {new Date(article.publishedAt).toLocaleDateString("vi-VN")}
                </span>
              </div>
              <ExternalLink className="w-3 h-3 opacity-50 group-hover:opacity-100" />
            </div>
          </a>
        ))}
      </div>
    </div>
  );
}