import { useState } from "react";
import {
  useGetReviews, useGetReviewStats, useRunReview,
  useGetEvaluationSummary,
  getGetReviewsQueryKey, getGetReviewStatsQueryKey, getGetSignalsQueryKey,
  getGetEvaluationSummaryQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Brain, TrendingUp, TrendingDown, CheckCircle2, XCircle,
  Target, ShieldAlert, RefreshCw, BarChart2, Star, BookOpen,
  ChevronDown, ChevronUp, Clock, Zap, Award, AlertTriangle,
} from "lucide-react";

const OUTCOME_MAP: Record<string, { label: string; color: string; icon: typeof CheckCircle2 }> = {
  TP2_HIT:            { label: "TP2 Đạt",        color: "text-emerald-400", icon: Star },
  TP1_HIT:            { label: "TP1 Đạt",        color: "text-green-400",   icon: CheckCircle2 },
  SL_HIT:             { label: "Stop Loss",       color: "text-red-400",    icon: XCircle },
  CORRECT_DIRECTION:  { label: "Đúng Hướng",     color: "text-blue-400",   icon: TrendingUp },
  WRONG_DIRECTION:    { label: "Sai Hướng",      color: "text-orange-400", icon: TrendingDown },
  STILL_ACTIVE:       { label: "Còn Hiệu Lực",   color: "text-yellow-400", icon: Clock },
};

function StatCard({ label, value, sub, color }: { label: string; value: string | number; sub?: string; color?: string }) {
  return (
    <div className="bg-card border border-border rounded-xl p-3 flex flex-col gap-1">
      <span className="text-[10px] text-muted-foreground uppercase tracking-wider">{label}</span>
      <span className={cn("text-xl font-bold font-mono", color || "text-foreground")}>{value}</span>
      {sub && <span className="text-[10px] text-muted-foreground">{sub}</span>}
    </div>
  );
}

function WinRateBar({ rate, label }: { rate: number; label: string }) {
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className={cn("font-mono font-semibold", rate >= 60 ? "text-green-400" : rate >= 40 ? "text-yellow-400" : "text-red-400")}>
          {rate}%
        </span>
      </div>
      <div className="h-1.5 bg-muted rounded-full overflow-hidden">
        <div
          className={cn("h-full rounded-full transition-all duration-700", rate >= 60 ? "bg-green-400" : rate >= 40 ? "bg-yellow-400" : "bg-red-400")}
          style={{ width: `${Math.min(100, rate)}%` }}
        />
      </div>
    </div>
  );
}

function EvaluationPanel() {
  const { data: evalData, isLoading } = useGetEvaluationSummary({
    query: { queryKey: getGetEvaluationSummaryQueryKey(), staleTime: 5 * 60 * 1000 },
  });

  if (isLoading) {
    return (
      <div className="space-y-2">
        <Skeleton className="h-20 w-full rounded-xl" />
        <div className="grid grid-cols-3 gap-2">
          {[1,2,3].map(i => <Skeleton key={i} className="h-16 rounded-xl" />)}
        </div>
      </div>
    );
  }

  if (!evalData || evalData.totalReviewed === 0) {
    return (
      <div className="bg-card border border-border rounded-xl p-4 flex items-center gap-3 text-muted-foreground text-xs">
        <Zap className="w-5 h-5 shrink-0 text-muted-foreground/40" />
        <span>Chưa có đủ dữ liệu đánh giá. Hệ thống sẽ tính toán sau 24 giờ.</span>
      </div>
    );
  }

  const wr = Math.round(evalData.winRate * 10) / 10;
  const wrColor = wr >= 60 ? "text-green-400" : wr >= 45 ? "text-yellow-400" : "text-red-400";
  const wrBg = wr >= 60 ? "from-green-500/10 to-transparent border-green-500/20" : wr >= 45 ? "from-yellow-500/10 to-transparent border-yellow-500/20" : "from-red-500/10 to-transparent border-red-500/20";

  return (
    <div className="space-y-3">
      <div className={cn("bg-gradient-to-r border rounded-xl p-4", wrBg)}>
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Award className={cn("w-4 h-4", wrColor)} />
            <span className="text-xs font-semibold text-foreground">Hiệu Suất Tổng Thể AI</span>
          </div>
          <span className="text-[10px] text-muted-foreground">{evalData.totalReviewed} tín hiệu đánh giá</span>
        </div>
        <div className="flex items-end gap-3">
          <span className={cn("text-4xl font-black font-mono", wrColor)}>{wr}%</span>
          <div className="pb-1 space-y-0.5">
            <div className="text-[10px] text-muted-foreground">Thắng: <span className="text-green-400 font-semibold">{evalData.correctSignals}</span></div>
            <div className="text-[10px] text-muted-foreground">Thua: <span className="text-red-400 font-semibold">{evalData.wrongSignals}</span></div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        <div className="bg-card border border-border rounded-xl p-3 text-center">
          <div className="text-[10px] text-muted-foreground mb-1">TP1 Đạt</div>
          <div className={cn("text-lg font-bold font-mono", evalData.tp1Rate >= 50 ? "text-green-400" : "text-yellow-400")}>
            {Math.round(evalData.tp1Rate)}%
          </div>
        </div>
        <div className="bg-card border border-border rounded-xl p-3 text-center">
          <div className="text-[10px] text-muted-foreground mb-1">TP2 Đạt</div>
          <div className={cn("text-lg font-bold font-mono", evalData.tp2Rate >= 35 ? "text-emerald-400" : "text-yellow-400")}>
            {Math.round(evalData.tp2Rate)}%
          </div>
        </div>
        <div className="bg-card border border-border rounded-xl p-3 text-center">
          <div className="text-[10px] text-muted-foreground mb-1">SL Chạm</div>
          <div className={cn("text-lg font-bold font-mono", evalData.slRate <= 25 ? "text-green-400" : "text-red-400")}>
            {Math.round(evalData.slRate)}%
          </div>
        </div>
      </div>

      <div className="bg-card border border-border rounded-xl p-3 space-y-2">
        <div className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider mb-2">Theo Hướng</div>
        <div className="grid grid-cols-2 gap-2">
          {(["LONG", "SHORT"] as const).map((dir) => {
            const dirStats = dir === "LONG" ? evalData.byDirection?.longStats : evalData.byDirection?.shortStats;
            if (!dirStats) return null;
            return (
              <div key={dir} className={cn(
                "rounded-lg p-2.5 border",
                dir === "LONG" ? "bg-green-400/5 border-green-400/20" : "bg-red-400/5 border-red-400/20"
              )}>
                <div className={cn("text-[10px] font-bold mb-1", dir === "LONG" ? "text-green-400" : "text-red-400")}>{dir}</div>
                <div className="text-base font-bold font-mono">{dirStats.winRate}%</div>
                <div className="text-[9px] text-muted-foreground">{dirStats.wins}/{dirStats.total} thắng</div>
              </div>
            );
          })}
        </div>
      </div>

      {evalData.bestSymbols && evalData.bestSymbols.length > 0 && (
        <div className="bg-card border border-border rounded-xl p-3">
          <div className="flex items-center gap-1.5 mb-2">
            <Star className="w-3.5 h-3.5 text-yellow-400" />
            <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Coin Hiệu Quả Nhất</span>
          </div>
          <div className="space-y-1.5">
            {evalData.bestSymbols.slice(0, 4).map((s) => (
              <div key={s.symbol} className="flex items-center gap-2">
                <span className="text-[11px] font-mono flex-1 text-foreground">{s.symbol}</span>
                <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-green-400 rounded-full" style={{ width: `${s.winRate}%` }} />
                </div>
                <span className="text-[11px] font-mono font-bold text-green-400 w-9 text-right">{s.winRate}%</span>
                <span className="text-[9px] text-muted-foreground w-8 text-right">{s.total}x</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {evalData.worstSymbols && evalData.worstSymbols.length > 0 && (
        <div className="bg-card border border-border rounded-xl p-3">
          <div className="flex items-center gap-1.5 mb-2">
            <AlertTriangle className="w-3.5 h-3.5 text-orange-400" />
            <span className="text-[10px] font-semibold text-muted-foreground uppercase tracking-wider">Coin Cần Chú Ý</span>
          </div>
          <div className="space-y-1.5">
            {evalData.worstSymbols.slice(0, 3).map((s) => (
              <div key={s.symbol} className="flex items-center gap-2">
                <span className="text-[11px] font-mono flex-1 text-foreground">{s.symbol}</span>
                <div className="flex-1 h-1 bg-muted rounded-full overflow-hidden">
                  <div className="h-full bg-red-400 rounded-full" style={{ width: `${s.winRate}%` }} />
                </div>
                <span className="text-[11px] font-mono font-bold text-red-400 w-9 text-right">{s.winRate}%</span>
                <span className="text-[9px] text-muted-foreground w-8 text-right">{s.total}x</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function ReviewCard({ review }: { review: any }) {
  const [expanded, setExpanded] = useState(false);
  const outcome = OUTCOME_MAP[review.outcome] || { label: review.outcome, color: "text-muted-foreground", icon: Clock };
  const Icon = outcome.icon;
  const dir = review.originalDirection === "LONG";
  const dateStr = new Date(review.reviewedAt).toLocaleDateString("vi-VN", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" });

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden" data-testid={`review-card-${review.id}`}>
      <button
        onClick={() => setExpanded((p) => !p)}
        className="w-full p-4 flex items-start justify-between gap-3 text-left"
        data-testid={`review-expand-${review.id}`}
      >
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="font-bold text-sm">{review.symbol}</span>
            <span className={cn("text-[10px] font-bold px-1.5 py-0.5 rounded border", dir ? "text-green-400 border-green-400/30 bg-green-400/10" : "text-red-400 border-red-400/30 bg-red-400/10")}>
              {review.originalDirection}
            </span>
            <span className={cn("flex items-center gap-1 text-xs font-semibold", outcome.color)}>
              <Icon className="w-3.5 h-3.5" />
              {outcome.label}
            </span>
          </div>
          <div className="flex gap-3 text-[11px] text-muted-foreground">
            <span>Vào: <span className="text-foreground font-mono">${review.entryPrice.toFixed(4)}</span></span>
            <span>Hiện: <span className={cn("font-mono", review.priceChangePct >= 0 ? "text-green-400" : "text-red-400")}>
              ${review.currentPrice.toFixed(4)}
            </span></span>
            <span className={cn("font-mono font-semibold", review.priceChangePct >= 0 ? "text-green-400" : "text-red-400")}>
              {review.priceChangePct >= 0 ? "+" : ""}{review.priceChangePct.toFixed(2)}%
            </span>
          </div>
          <div className="text-[10px] text-muted-foreground mt-1">{dateStr}</div>
        </div>
        {expanded ? <ChevronUp className="w-4 h-4 text-muted-foreground shrink-0 mt-1" /> : <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0 mt-1" />}
      </button>

      {expanded && (
        <div className="border-t border-border px-4 pb-4 pt-3 space-y-3">
          <div className="grid grid-cols-3 gap-2 text-[11px]">
            {[
              { l: "TP1", v: review.takeProfit1.toFixed(4), ok: review.tp1Reached },
              { l: "TP2", v: review.takeProfit2.toFixed(4), ok: review.tp2Reached },
              { l: "SL",  v: review.stopLoss.toFixed(4),    ok: review.slHit, bad: true },
            ].map((item) => (
              <div key={item.l} className={cn(
                "rounded-lg p-2 text-center border",
                item.ok && !item.bad ? "bg-green-400/10 border-green-400/30" :
                item.ok && item.bad  ? "bg-red-400/10 border-red-400/30" :
                "bg-muted/30 border-border"
              )}>
                <div className="text-[10px] text-muted-foreground mb-0.5">{item.l}</div>
                <div className={cn("font-mono font-semibold", item.ok && !item.bad ? "text-green-400" : item.ok && item.bad ? "text-red-400" : "text-foreground")}>
                  ${item.v}
                </div>
              </div>
            ))}
          </div>

          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="bg-muted/20 rounded-lg p-2">
              <div className="text-[10px] text-muted-foreground mb-1">Xu hướng hiện tại</div>
              <div>H1: <span className="font-semibold">{review.currentTrendH1 === "Uptrend" ? "Tăng" : review.currentTrendH1 === "Downtrend" ? "Giảm" : "Ngang"}</span></div>
              <div>H4: <span className="font-semibold">{review.currentTrendH4 === "Uptrend" ? "Tăng" : review.currentTrendH4 === "Downtrend" ? "Giảm" : "Ngang"}</span></div>
            </div>
            <div className="bg-muted/20 rounded-lg p-2">
              <div className="text-[10px] text-muted-foreground mb-1">Tín hiệu còn hiệu lực</div>
              <div className={cn("font-semibold text-sm", review.stillValid ? "text-green-400" : "text-red-400")}>
                {review.stillValid ? "Còn hiệu lực" : "Không còn hiệu lực"}
              </div>
              <div className="text-[10px] text-muted-foreground">Độ tin cậy: {review.confidence}%</div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="rounded-lg bg-blue-500/5 border border-blue-500/20 p-3">
              <div className="flex items-center gap-1.5 mb-1.5 text-blue-400">
                <Brain className="w-3.5 h-3.5" />
                <span className="text-[11px] font-semibold uppercase tracking-wide">Nhận Xét AI</span>
              </div>
              <p className="text-xs text-foreground/80 leading-relaxed">{review.reflection}</p>
            </div>

            <div className="rounded-lg bg-purple-500/5 border border-purple-500/20 p-3">
              <div className="flex items-center gap-1.5 mb-1.5 text-purple-400">
                <TrendingUp className="w-3.5 h-3.5" />
                <span className="text-[11px] font-semibold uppercase tracking-wide">Điều Gì Đã Thay Đổi</span>
              </div>
              <p className="text-xs text-foreground/80 leading-relaxed">{review.whatChanged}</p>
            </div>

            <div className="rounded-lg bg-amber-500/5 border border-amber-500/20 p-3">
              <div className="flex items-center gap-1.5 mb-1.5 text-amber-400">
                <BookOpen className="w-3.5 h-3.5" />
                <span className="text-[11px] font-semibold uppercase tracking-wide">Bài Học</span>
              </div>
              <p className="text-xs text-foreground/80 leading-relaxed">{review.lesson}</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function Review() {
  const queryClient = useQueryClient();
  const [tab, setTab] = useState<"reviews" | "stats" | "eval">("eval");

  const { data: reviewsData, isLoading: reviewsLoading } = useGetReviews({
    query: { queryKey: getGetReviewsQueryKey() },
  });
  const { data: stats, isLoading: statsLoading } = useGetReviewStats({
    query: { queryKey: getGetReviewStatsQueryKey() },
  });
  const runReview = useRunReview({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetReviewsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetReviewStatsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetSignalsQueryKey() });
        queryClient.invalidateQueries({ queryKey: getGetEvaluationSummaryQueryKey() });
      },
    },
  });

  const reviews = reviewsData?.reviews || [];
  const todayReviews = reviews.filter((r) => {
    const reviewDate = new Date(r.reviewedAt).toDateString();
    return reviewDate === new Date().toDateString();
  });

  return (
    <div className="flex flex-col min-h-full pb-12">
      <div className="p-4 pb-0">
        <div className="flex items-center justify-between mb-1">
          <h1 className="text-lg font-bold flex items-center gap-2">
            <Brain className="w-5 h-5 text-primary" />
            Tự Đánh Giá AI
          </h1>
          <button
            onClick={() => runReview.mutate(undefined)}
            disabled={runReview.isPending}
            className="flex items-center gap-1.5 text-xs bg-primary/10 border border-primary/30 text-primary rounded-lg px-3 py-1.5 active:scale-95 transition-transform disabled:opacity-50"
            data-testid="button-run-review"
          >
            <RefreshCw className={cn("w-3.5 h-3.5", runReview.isPending && "animate-spin")} />
            {runReview.isPending ? "Đang chạy..." : "Chạy Đánh Giá"}
          </button>
        </div>
        <p className="text-[11px] text-muted-foreground mb-4">
          Hệ thống tự động đánh giá tín hiệu sau 24 giờ
        </p>

        <div className="flex gap-1.5 mb-4">
          {([
            { key: "eval",    label: "Hiệu Suất" },
            { key: "reviews", label: "Kết Quả" },
            { key: "stats",   label: "Thống Kê" },
          ] as const).map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={cn(
                "flex-1 py-2 rounded-lg text-xs font-semibold transition-all",
                tab === t.key ? "bg-primary text-primary-foreground" : "bg-card border border-border text-muted-foreground"
              )}
              data-testid={`tab-${t.key}`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {tab === "eval" && (
        <div className="px-4 space-y-3">
          <EvaluationPanel />
        </div>
      )}

      {tab === "reviews" && (
        <div className="px-4 space-y-3">
          {reviewsLoading ? (
            [1, 2, 3].map((i) => <Skeleton key={i} className="h-24 w-full rounded-xl" />)
          ) : reviews.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <Brain className="w-12 h-12 text-muted-foreground/30 mb-3" />
              <p className="text-sm text-muted-foreground font-medium">Chưa có đánh giá nào</p>
              <p className="text-xs text-muted-foreground/70 mt-1 max-w-xs">
                Hệ thống sẽ tự động đánh giá tín hiệu sau 24 giờ. Bạn cũng có thể nhấn "Chạy Đánh Giá" để kiểm tra thủ công.
              </p>
            </div>
          ) : (
            <>
              {todayReviews.length > 0 && (
                <div className="bg-primary/5 border border-primary/20 rounded-xl p-3 mb-2">
                  <div className="text-xs font-semibold text-primary mb-1">Hôm nay: {todayReviews.length} đánh giá mới</div>
                  <div className="text-[11px] text-muted-foreground">
                    Thắng: {todayReviews.filter((r) => r.tp1Reached || r.tp2Reached || r.directionCorrect).length} / {todayReviews.length}
                  </div>
                </div>
              )}
              {reviews.map((review) => (
                <ReviewCard key={review.id} review={review} />
              ))}
            </>
          )}
        </div>
      )}

      {tab === "stats" && (
        <div className="px-4 space-y-4">
          {statsLoading ? (
            [1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-24 w-full rounded-xl" />)
          ) : !stats || stats.totalReviewed === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <BarChart2 className="w-12 h-12 text-muted-foreground/30 mb-3" />
              <p className="text-sm text-muted-foreground font-medium">Chưa có dữ liệu thống kê</p>
              <p className="text-xs text-muted-foreground/70 mt-1 max-w-xs">
                Thống kê sẽ được tạo tự động sau khi có ít nhất một đánh giá.
              </p>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 gap-2">
                <StatCard label="Tổng Tín Hiệu" value={stats.totalSignals} sub="Đã lưu" />
                <StatCard label="Đã Đánh Giá" value={stats.reviewedSignals} sub="Sau 24 giờ" />
                <StatCard
                  label="Tỷ Lệ Thắng"
                  value={`${stats.winRate}%`}
                  sub="Đúng hướng/TP đạt"
                  color={stats.winRate >= 60 ? "text-green-400" : stats.winRate >= 40 ? "text-yellow-400" : "text-red-400"}
                />
                <StatCard label="Độ Tin Cậy TB" value={`${stats.averageConfidence}%`} sub="Trung bình" />
              </div>

              <div className="bg-card border border-border rounded-xl p-4 space-y-3">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                  <Target className="w-3.5 h-3.5" /> Kết Quả Chi Tiết
                </h3>
                <WinRateBar rate={stats.tp2Rate} label="TP2 Đạt" />
                <WinRateBar rate={stats.tp1Rate} label="TP1 Đạt" />
                <WinRateBar rate={stats.winRate} label="Đúng Hướng" />
                <WinRateBar rate={stats.slRate} label="Stop Loss Chạm" />
              </div>

              <div className="bg-card border border-border rounded-xl p-4 space-y-3">
                <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                  <TrendingUp className="w-3.5 h-3.5" /> Theo Hướng Giao Dịch
                </h3>
                <div className="grid grid-cols-2 gap-3">
                  {(["LONG", "SHORT"] as const).map((dir) => {
                    const d = stats.byDirection[dir];
                    return (
                      <div key={dir} className={cn(
                        "rounded-lg p-3 border",
                        dir === "LONG" ? "bg-green-400/5 border-green-400/20" : "bg-red-400/5 border-red-400/20"
                      )}>
                        <div className={cn("text-xs font-bold mb-1", dir === "LONG" ? "text-green-400" : "text-red-400")}>{dir}</div>
                        <div className="text-lg font-bold font-mono">{d.winRate}%</div>
                        <div className="text-[10px] text-muted-foreground">{d.wins}/{d.total} thắng</div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {stats.bySymbol.length > 0 && (
                <div className="bg-card border border-border rounded-xl p-4 space-y-2">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                    <BarChart2 className="w-3.5 h-3.5" /> Theo Coin
                  </h3>
                  {stats.bySymbol.slice(0, 8).map((s) => (
                    <div key={s.symbol} className="flex items-center gap-2">
                      <span className="text-xs font-mono w-24 shrink-0 text-foreground">{s.symbol}</span>
                      <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
                        <div
                          className={cn("h-full rounded-full", s.winRate >= 60 ? "bg-green-400" : s.winRate >= 40 ? "bg-yellow-400" : "bg-red-400")}
                          style={{ width: `${s.winRate}%` }}
                        />
                      </div>
                      <span className={cn("text-xs font-mono font-semibold w-10 text-right shrink-0", s.winRate >= 60 ? "text-green-400" : s.winRate >= 40 ? "text-yellow-400" : "text-red-400")}>
                        {s.winRate}%
                      </span>
                      <span className="text-[10px] text-muted-foreground w-12 text-right shrink-0">{s.wins}/{s.total}</span>
                    </div>
                  ))}
                </div>
              )}

              {stats.bestSetups.length > 0 && (
                <div className="bg-card border border-border rounded-xl p-4 space-y-2">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-muted-foreground flex items-center gap-1.5">
                    <Star className="w-3.5 h-3.5 text-yellow-400" /> Thiết Lập Tốt Nhất
                  </h3>
                  {stats.bestSetups.slice(0, 5).map((setup, i) => (
                    <div key={`${setup.symbol}-${setup.direction}`} className="flex items-center gap-2">
                      <span className="text-[10px] text-muted-foreground w-4 shrink-0">{i + 1}.</span>
                      <span className="text-xs font-mono flex-1">{setup.symbol}</span>
                      <span className={cn("text-[10px] font-bold px-1.5 py-0.5 rounded", setup.direction === "LONG" ? "text-green-400 bg-green-400/10" : "text-red-400 bg-red-400/10")}>
                        {setup.direction}
                      </span>
                      <span className={cn("text-xs font-mono font-bold", setup.winRate >= 60 ? "text-green-400" : setup.winRate >= 40 ? "text-yellow-400" : "text-red-400")}>
                        {setup.winRate}%
                      </span>
                      <span className="text-[10px] text-muted-foreground">{setup.count}x</span>
                    </div>
                  ))}
                </div>
              )}

              <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-3">
                <div className="flex items-center gap-1.5 mb-1">
                  <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-[10px] font-semibold text-amber-400 uppercase tracking-wide">Tuyên Bố Miễn Trừ Trách Nhiệm</span>
                </div>
                <p className="text-[11px] text-muted-foreground leading-relaxed">
                  Hiệu suất trong quá khứ không đảm bảo kết quả trong tương lai. Đây chỉ là công cụ phân tích tham khảo, không phải lời khuyên đầu tư.
                </p>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
}
