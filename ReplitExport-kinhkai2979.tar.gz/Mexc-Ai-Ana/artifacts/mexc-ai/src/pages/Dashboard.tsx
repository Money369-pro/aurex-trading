import { useGetDashboard, getGetDashboardQueryKey } from "@workspace/api-client-react";
import { useAlerts } from "@/hooks/useAlerts";
import { useEffect, useMemo } from "react";
import { Link } from "wouter";
import { ArrowUpRight, ArrowDownRight, TrendingUp, TrendingDown, Activity, Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { data, isLoading } = useGetDashboard({
    query: {
      queryKey: getGetDashboardQueryKey()
    }
  });

  const { checkPrices } = useAlerts();

  useEffect(() => {
    if (data) {
      const prices: Record<string, number> = {
        [data.btc.symbol]: data.btc.price,
        [data.eth.symbol]: data.eth.price,
        [data.sol.symbol]: data.sol.price,
      };
      data.topSignals.forEach(s => {
        prices[s.symbol] = s.price;
      });
      checkPrices(prices);
    }
  }, [data, checkPrices]);

  if (isLoading || !data) {
    return (
      <div className="p-4 space-y-6">
        <div className="flex justify-between items-center">
          <Skeleton className="h-8 w-32" />
          <Skeleton className="h-4 w-20" />
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[1, 2, 3].map(i => <Skeleton key={i} className="h-20 w-full" />)}
        </div>
        <Skeleton className="h-24 w-full" />
        <div className="space-y-3">
          {[1, 2, 3, 4, 5].map(i => <Skeleton key={i} className="h-16 w-full" />)}
        </div>
      </div>
    );
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2, maximumFractionDigits: 6 }).format(price);
  };

  const formatPct = (pct: number) => {
    return `${pct > 0 ? "+" : ""}${pct.toFixed(2)}%`;
  };

  return (
    <div className="flex flex-col space-y-5 p-4 animate-in fade-in slide-in-from-bottom-2 duration-300">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-white">Tổng Quan</h1>
          <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
            <Clock className="w-3 h-3" /> Cập nhật: {new Date(data.updatedAt).toLocaleTimeString("vi-VN")}
          </p>
        </div>
      </header>

      {/* Main Prices */}
      <div className="grid grid-cols-3 gap-2">
        {[data.btc, data.eth, data.sol].map(coin => (
          <div key={coin.symbol} className="bg-white/5 border border-white/10 rounded-lg p-3 flex flex-col justify-between">
            <span className="text-xs font-bold text-muted-foreground">{coin.symbol}</span>
            <div className="mt-1">
              <span className="text-sm font-medium text-white block">{formatPrice(coin.price)}</span>
              <span className={cn("text-[10px] font-medium flex items-center", coin.change24h >= 0 ? "text-green-500" : "text-red-500")}>
                {coin.change24h >= 0 ? <TrendingUp className="w-3 h-3 mr-0.5" /> : <TrendingDown className="w-3 h-3 mr-0.5" />}
                {formatPct(coin.change24h)}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Market Sentiment */}
      <div className="bg-white/5 border border-white/10 rounded-lg p-4 flex items-center justify-between">
        <div>
          <div className="text-xs text-muted-foreground mb-1">Tâm Lý Thị Trường</div>
          <div className="text-lg font-bold text-white capitalize">{data.marketSentiment}</div>
        </div>
        <div className="text-right">
          <div className="text-xs text-muted-foreground mb-1">Sợ Hãi & Tham Lam</div>
          <div className={cn("text-2xl font-bold", data.fearGreedIndex > 50 ? "text-green-500" : "text-red-500")}>
            {data.fearGreedIndex}
          </div>
        </div>
      </div>

      {/* Top Signals */}
      <div>
        <h2 className="text-sm font-bold text-muted-foreground mb-3 uppercase tracking-wider flex items-center gap-1">
          <Activity className="w-4 h-4" /> Tín Hiệu Nổi Bật
        </h2>
        <div className="space-y-2">
          {data.topSignals.map(signal => (
            <Link key={signal.symbol} href={`/coin/${signal.symbol.replace("/", "_")}`} className="block">
              <div className="bg-card border border-border hover:bg-white/5 transition-colors rounded-lg p-3 flex items-center justify-between">
                <div>
                  <div className="font-bold text-white text-sm">{signal.symbol}</div>
                  <div className="text-xs text-muted-foreground">{formatPrice(signal.price)}</div>
                </div>
                
                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <div className={cn("text-xs font-bold px-1.5 py-0.5 rounded", signal.direction === "LONG" ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500")}>
                      {signal.direction}
                    </div>
                    <div className="text-[10px] text-muted-foreground mt-0.5">Điểm: {signal.score}</div>
                  </div>
                  <div className={cn("w-1.5 h-8 rounded-full", 
                    signal.score >= 80 ? "bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]" : 
                    signal.score >= 65 ? "bg-amber-500" : "bg-muted"
                  )} />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}