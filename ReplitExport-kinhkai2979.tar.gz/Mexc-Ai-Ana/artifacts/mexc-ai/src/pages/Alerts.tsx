import { useState } from "react";
import { useAlerts } from "@/hooks/useAlerts";
import { BellRing, Plus, Trash2, CheckCircle2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

export default function Alerts() {
  const { alerts, addAlert, removeAlert } = useAlerts();
  const [symbol, setSymbol] = useState("");
  const [condition, setCondition] = useState<">" | "<">(">");
  const [price, setPrice] = useState("");

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!symbol || !price || isNaN(Number(price))) return;
    addAlert({
      symbol: symbol.toUpperCase(),
      condition,
      price: Number(price)
    });
    setSymbol("");
    setPrice("");
  };

  const formatPrice = (p: number) => {
    return new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", minimumFractionDigits: 2 }).format(p);
  };

  return (
    <div className="flex flex-col space-y-6 p-4 pb-12">
      <header className="flex items-center gap-2">
        <BellRing className="w-5 h-5 text-white" />
        <h1 className="text-xl font-bold tracking-tight text-white">Cảnh Báo Giá</h1>
      </header>

      <form onSubmit={handleAdd} className="bg-card border border-border rounded-xl p-4 space-y-3">
        <h2 className="text-sm font-bold text-white mb-1">Thêm Cảnh Báo Mới</h2>
        <div className="grid grid-cols-3 gap-2">
          <Input 
            placeholder="Mã (BTC)" 
            value={symbol}
            onChange={e => setSymbol(e.target.value)}
            className="col-span-1 bg-background border-border uppercase"
            required
          />
          <Select value={condition} onValueChange={(v: ">" | "<") => setCondition(v)}>
            <SelectTrigger className="col-span-1 bg-background border-border">
              <SelectValue placeholder="Điều kiện" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value=">">Lớn hơn {">"}</SelectItem>
              <SelectItem value="<">Nhỏ hơn {"<"}</SelectItem>
            </SelectContent>
          </Select>
          <Input 
            placeholder="Giá" 
            type="number"
            step="any"
            value={price}
            onChange={e => setPrice(e.target.value)}
            className="col-span-1 bg-background border-border"
            required
          />
        </div>
        <Button type="submit" className="w-full font-bold">
          <Plus className="w-4 h-4 mr-2" /> Thêm Cảnh Báo
        </Button>
      </form>

      <div className="space-y-3">
        <h2 className="text-sm font-bold text-muted-foreground uppercase tracking-wider">Danh Sách Cảnh Báo</h2>
        
        {alerts.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground text-sm bg-white/5 rounded-xl border border-white/5 border-dashed">
            Chưa có cảnh báo nào
          </div>
        ) : (
          <div className="space-y-2">
            {alerts.sort((a,b) => b.createdAt - a.createdAt).map(alert => (
              <div 
                key={alert.id} 
                className={cn(
                  "bg-card border p-3 rounded-lg flex items-center justify-between transition-opacity",
                  alert.triggered ? "border-green-500/30 opacity-70" : "border-border"
                )}
              >
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-white">{alert.symbol}</span>
                    <span className={cn("text-xs font-bold px-1.5 py-0.5 rounded", alert.condition === ">" ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500")}>
                      {alert.condition === ">" ? "Vượt qua" : "Giảm dưới"}
                    </span>
                  </div>
                  <div className="font-mono text-sm text-muted-foreground mt-1">
                    {formatPrice(alert.price)}
                  </div>
                </div>
                
                <div className="flex items-center gap-3">
                  {alert.triggered && (
                    <span className="text-xs text-green-500 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Đã chạm
                    </span>
                  )}
                  <button 
                    onClick={() => removeAlert(alert.id)}
                    className="p-2 text-muted-foreground hover:text-red-500 hover:bg-red-500/10 rounded-md transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}