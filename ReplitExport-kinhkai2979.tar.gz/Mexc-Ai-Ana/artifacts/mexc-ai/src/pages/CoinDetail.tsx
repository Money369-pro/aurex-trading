import { useGetCoinDetail, getGetCoinDetailQueryKey } from "@workspace/api-client-react";
import { useParams, useLocation } from "wouter";
import {
  ArrowLeft, AlertTriangle, TrendingUp, TrendingDown,
  Minus, WifiOff, Activity, BarChart2, Zap, Waves, Wind,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";

// ── Helpers ──────────────────────────────────────────────────────────────────

const fmt = (n: number) =>
  new Intl.NumberFormat("en-US", {
    style: "currency", currency: "USD",
    minimumFractionDigits: 2, maximumFractionDigits: 6,
  }).format(n);

const round2 = (n: number) => Math.round(n * 100) / 100;

function RegimeBadge({ regime }: { regime: string }) {
  const map: Record<string, { label: string; cls: string }> = {
    Uptrend:       { label: "Tăng Trend",    cls: "bg-green-500/15 text-green-400 border-green-500/30" },
    Downtrend:     { label: "Giảm Trend",    cls: "bg-red-500/15 text-red-400 border-red-500/30" },
    Sideways:      { label: "Đi Ngang",      cls: "bg-yellow-500/15 text-yellow-400 border-yellow-500/30" },
    HighVolatility:{ label: "Biến Động Cao", cls: "bg-orange-500/15 text-orange-400 border-orange-500/30" },
    Breakout:      { label: "Bứt Phá",       cls: "bg-purple-500/15 text-purple-400 border-purple-500/30" },
  };
  const { label, cls } = map[regime] || { label: regime, cls: "bg-muted/20 text-muted-foreground border-border" };
  return (
    <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded-full border", cls)}>
      {label}
    </span>
  );
}

function ScoreBar({ value, label, color }: { value: number; label: string; color: string }) {
  return (
    <div className="space-y-0.5">
      <div className="flex justify-between text-[10px]">
        <span className="text-muted-foreground">{label}</span>
        <span className={cn("font-mono font-bold", color)}>{value}%</span>
      </div>
      <div className="h-1 bg-muted rounded-full overflow-hidden">
        <div
          className={cn("h-full rounded-full transition-all duration-700", color.replace("text-", "bg-"))}
          style={{ width: `${Math.min(100, value)}%` }}
        />
      </div>
    </div>
  );
}

function TrendBadge({ trend }: { trend: string }) {
  if (trend === "Uptrend") return <span className="text-[10px] font-bold text-green-400">↑ Tăng</span>;
  if (trend === "Downtrend") return <span className="text-[10px] font-bold text-red-400">↓ Giảm</span>;
  return <span className="text-[10px] font-bold text-yellow-400">→ Ngang</span>;
}

// ── Component ─────────────────────────────────────────────────────────────────

export default function CoinDetail() {
  const params = useParams<{ symbol: string }>();
  const symbol = params.symbol || "";
  const [, setLocation] = useLocation();

  const { data, isLoading, isError } = useGetCoinDetail(symbol, {
    query: {
      enabled: !!symbol,
      queryKey: getGetCoinDetailQueryKey(symbol),
      retry: 1,
    },
  });

  if (isLoading) {
    return (
      <div className="p-4 space-y-3">
        <Skeleton className="h-6 w-20" />
        <Skeleton className="h-20 w-full rounded-xl" />
        <Skeleton className="h-32 w-full rounded-xl" />
        <Skeleton className="h-48 w-full rounded-xl" />
        <Skeleton className="h-36 w-full rounded-xl" />
      </div>
    );
  }

  if (isError || !data) {
    return (
      <div className="flex flex-col items-start p-4 gap-4">
        <button onClick={() => setLocation("/scanner")} className="flex items-center gap-1 text-sm text-muted-foreground">
          <ArrowLeft className="w-4 h-4" /> Quay lại
        </button>
        <div className="w-full flex flex-col items-center justify-center py-16 text-center gap-3">
          <WifiOff className="w-12 h-12 text-muted-foreground/30" />
          <p className="text-sm font-semibold">Không tìm thấy "{symbol}"</p>
          <p className="text-xs text-muted-foreground max-w-xs">Cặp này không có trên MEXC Futures hoặc đã ngừng hoạt động.</p>
          <button onClick={() => setLocation("/scanner")} className="mt-2 px-4 py-2 rounded-lg bg-primary/10 border border-primary/30 text-primary text-sm">
            Quay lại Scanner
          </button>
        </div>
      </div>
    );
  }

  const isLong  = data.direction === "LONG";
  const isShort = data.direction === "SHORT";
  const isHold  = data.direction === "HOLD";

  const dirCls  = isLong ? "text-green-400 bg-green-500/10 border-green-500/30"
                : isShort ? "text-red-400 bg-red-500/10 border-red-500/30"
                : "text-yellow-400 bg-yellow-500/10 border-yellow-500/30";
  const DirIcon = isLong ? TrendingUp : isShort ? TrendingDown : Minus;

  return (
    <div className="flex flex-col gap-3 p-4 pb-20 animate-in fade-in duration-200">

      {/* Back */}
      <button onClick={() => window.history.back()} className="flex items-center gap-1 text-sm text-muted-foreground w-fit -mb-1">
        <ArrowLeft className="w-4 h-4" /> Quay lại
      </button>

      {/* ── Header ─────────────────────────────────────────────────────────── */}
      <div className="flex items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-black tracking-tight" data-testid="coin-symbol">{data.symbol}</h1>
          <div className="flex items-center gap-2 mt-0.5">
            <span className="text-lg font-mono font-semibold" data-testid="coin-price">{fmt(data.price)}</span>
            <span className={cn("text-sm font-bold", data.change24h >= 0 ? "text-green-400" : "text-red-400")}>
              {data.change24h >= 0 ? "+" : ""}{data.change24h.toFixed(2)}%
            </span>
          </div>
          <div className="flex items-center gap-2 mt-1.5">
            <RegimeBadge regime={data.regime} />
            <span className="text-[10px] text-muted-foreground">Lực: {data.regimeStrength}%</span>
          </div>
        </div>
        <div className={cn("flex items-center gap-1.5 px-3 py-2 rounded-xl border font-bold text-sm shrink-0", dirCls)} data-testid="coin-direction">
          <DirIcon className="w-4 h-4" />
          {data.direction}
        </div>
      </div>

      {/* ── Score Breakdown ─────────────────────────────────────────────────── */}
      <div className="bg-card border border-border rounded-xl p-3.5 space-y-2">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">
            <Zap className="w-3.5 h-3.5 text-primary" /> Điểm Tín Hiệu
          </span>
          <div className="flex items-center gap-2">
            <span className={cn("text-xl font-black font-mono",
              data.score >= 80 ? "text-green-400" : data.score >= 65 ? "text-yellow-400" : "text-red-400"
            )}>{data.score}</span>
            <span className="text-xs text-muted-foreground">/100</span>
            <span className={cn("text-[10px] font-bold px-2 py-0.5 rounded-full border",
              data.score >= 80 ? "text-green-400 border-green-500/30 bg-green-500/10"
              : data.score >= 65 ? "text-yellow-400 border-yellow-500/30 bg-yellow-500/10"
              : "text-red-400 border-red-500/30 bg-red-500/10"
            )}>{data.signalStrength}</span>
          </div>
        </div>
        <ScoreBar value={data.trendScore} label="Xu hướng"   color={data.trendScore >= 60 ? "text-green-400" : data.trendScore <= 40 ? "text-red-400" : "text-yellow-400"} />
        <ScoreBar value={data.momentumScore} label="Đà động lực" color={data.momentumScore >= 60 ? "text-green-400" : data.momentumScore <= 40 ? "text-red-400" : "text-yellow-400"} />
        <ScoreBar value={data.volumeScore} label="Khối lượng"  color={data.volumeScore >= 60 ? "text-green-400" : data.volumeScore <= 40 ? "text-red-400" : "text-yellow-400"} />
        <ScoreBar value={data.volatilityScore} label="Biến động"  color={data.volatilityScore >= 60 ? "text-green-400" : data.volatilityScore <= 40 ? "text-red-400" : "text-yellow-400"} />
      </div>

      {/* ── Reasons ────────────────────────────────────────────────────────── */}
      {data.reasons.length > 0 && (
        <div className="bg-card border border-border rounded-xl p-3.5">
          <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-2.5 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-primary" /> Lý Do Tín Hiệu
          </div>
          <div className="space-y-1.5">
            {data.reasons.map((r, i) => {
              const isPositive = r.startsWith("✓");
              const isNegative = r.startsWith("✗");
              const isWarn     = r.startsWith("⚠") || r.startsWith("⏸");
              return (
                <div key={i} className={cn(
                  "text-xs px-2.5 py-1.5 rounded-lg leading-relaxed",
                  isPositive ? "bg-green-500/8 text-green-300 border border-green-500/15"
                  : isNegative ? "bg-red-500/8 text-red-300 border border-red-500/15"
                  : isWarn ? "bg-yellow-500/8 text-yellow-300 border border-yellow-500/15"
                  : "bg-muted/30 text-foreground/70 border border-border"
                )}>
                  {r}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ── Suggestion ─────────────────────────────────────────────────────── */}
      {data.suggestion && !isHold && (
        <div className={cn("rounded-xl p-4 border", isLong ? "bg-green-500/5 border-green-500/20" : "bg-red-500/5 border-red-500/20")}>
          <h2 className={cn("font-bold text-sm mb-3 flex items-center gap-2", isLong ? "text-green-400" : "text-red-400")}>
            <Activity className="w-4 h-4" /> Đề Xuất Giao Dịch
          </h2>
          <div className="grid grid-cols-2 gap-2.5 text-xs mb-3">
            <div>
              <span className="text-muted-foreground block mb-0.5">Vùng Vào Lệnh</span>
              <span className="font-mono text-foreground">{fmt(data.suggestion.entryMin)} – {fmt(data.suggestion.entryMax)}</span>
            </div>
            <div>
              <span className="text-muted-foreground block mb-0.5">Cắt Lỗ (SL)</span>
              <span className="font-mono text-red-400" data-testid="coin-sl">{fmt(data.suggestion.stopLoss)}</span>
            </div>
            <div>
              <span className="text-muted-foreground block mb-0.5">Chốt Lời 1 (TP1)</span>
              <span className="font-mono text-green-400" data-testid="coin-tp1">{fmt(data.suggestion.takeProfit1)}</span>
            </div>
            <div>
              <span className="text-muted-foreground block mb-0.5">Chốt Lời 2 (TP2)</span>
              <span className="font-mono text-green-400" data-testid="coin-tp2">{fmt(data.suggestion.takeProfit2)}</span>
            </div>
          </div>
          <div className="flex items-center gap-2 mb-2.5">
            <span className="text-[10px] text-muted-foreground shrink-0">Độ tin cậy</span>
            <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden">
              <div
                className={cn("h-full rounded-full transition-all duration-700",
                  data.suggestion.confidence >= 80 ? "bg-green-400"
                  : data.suggestion.confidence >= 65 ? "bg-yellow-400" : "bg-red-400"
                )}
                style={{ width: `${data.suggestion.confidence}%` }}
              />
            </div>
            <span className="text-xs font-bold font-mono shrink-0">{data.suggestion.confidence}%</span>
          </div>
          <p className="text-[11px] text-muted-foreground leading-relaxed bg-black/20 rounded-lg p-2.5" data-testid="coin-reasoning">
            {data.suggestion.reasoning}
          </p>
        </div>
      )}

      {/* HOLD state */}
      {isHold && (
        <div className="bg-yellow-500/5 border border-yellow-500/20 rounded-xl p-4">
          <div className="flex items-center gap-2 mb-2">
            <Minus className="w-4 h-4 text-yellow-400" />
            <span className="text-sm font-bold text-yellow-400">Chờ Xác Nhận (HOLD)</span>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed">{data.suggestion?.reasoning}</p>
          <p className="text-[11px] text-yellow-400/70 mt-2">Điểm {data.score}/100 — dưới ngưỡng tín hiệu 65. Chờ thêm xác nhận từ thị trường.</p>
        </div>
      )}

      {/* ── RSI Multi-Timeframe ─────────────────────────────────────────────── */}
      <div className="bg-card border border-border rounded-xl p-3.5">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <Waves className="w-3.5 h-3.5 text-primary" /> RSI Đa Khung Thời Gian
        </div>
        <div className="grid grid-cols-3 gap-2">
          {[{ label: "RSI(7)", value: data.rsi7 }, { label: "RSI(14)", value: data.rsi14 }, { label: "RSI(21)", value: data.rsi21 }].map(({ label, value }) => {
            const color = value > 70 ? "text-red-400" : value < 30 ? "text-green-400" : value > 55 ? "text-green-400" : value < 45 ? "text-red-400" : "text-yellow-400";
            const zone  = value > 70 ? "Quá mua" : value < 30 ? "Quá bán" : value > 55 ? "Tích cực" : value < 45 ? "Yếu" : "Trung tính";
            return (
              <div key={label} className="bg-muted/20 rounded-lg p-2.5 text-center">
                <div className="text-[10px] text-muted-foreground mb-1">{label}</div>
                <div className={cn("text-lg font-black font-mono", color)} data-testid={`coin-${label.toLowerCase().replace("(", "").replace(")", "")}`}>{value.toFixed(1)}</div>
                <div className={cn("text-[9px] mt-0.5", color)}>{zone}</div>
              </div>
            );
          })}
        </div>
        <p className="text-[11px] text-muted-foreground mt-2.5 leading-relaxed">{data.rsiExplanation}</p>
      </div>

      {/* ── EMA Stack ──────────────────────────────────────────────────────── */}
      <div className="bg-card border border-border rounded-xl p-3.5">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <BarChart2 className="w-3.5 h-3.5 text-primary" /> EMA Stack (H1)
        </div>
        <div className="space-y-2">
          {[
            { label: "EMA(20)",  val: data.ema20,  ref: data.price, testId: "coin-ema20" },
            { label: "EMA(50)",  val: data.ema50,  ref: data.ema20, testId: "coin-ema50" },
            { label: "EMA(100)", val: data.ema100, ref: data.ema50, testId: "coin-ema100" },
            { label: "EMA(200)", val: data.ema200, ref: data.ema100, testId: "coin-ema200" },
          ].map(({ label, val, ref, testId }, i) => {
            const above = i === 0 ? data.price > val : ref > val;
            return (
              <div key={label} className="flex items-center justify-between text-xs">
                <span className="text-muted-foreground w-16 shrink-0">{label}</span>
                <div className="flex-1 h-0.5 bg-muted mx-2 rounded-full">
                  <div className={cn("h-full rounded-full", above ? "bg-green-400" : "bg-red-400")} style={{ width: "100%" }} />
                </div>
                <span className="font-mono text-foreground" data-testid={testId}>{val.toFixed(4)}</span>
                <span className={cn("text-[10px] ml-2 w-12 text-right shrink-0", above ? "text-green-400" : "text-red-400")}>
                  {above ? "▲ trên" : "▼ dưới"}
                </span>
              </div>
            );
          })}
        </div>
        <p className="text-[11px] text-muted-foreground mt-2.5 leading-relaxed">{data.emaExplanation}</p>
      </div>

      {/* ── MACD ──────────────────────────────────────────────────────────── */}
      <div className="bg-card border border-border rounded-xl p-3.5">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <Activity className="w-3.5 h-3.5 text-primary" /> MACD (12,26,9)
        </div>
        <div className="grid grid-cols-3 gap-2 mb-2.5">
          {[
            { label: "MACD",      val: data.macdValue,     testId: "coin-macd" },
            { label: "Signal",    val: data.macdSignal,    testId: "coin-signal" },
            { label: "Histogram", val: data.macdHistogram, testId: "coin-histogram" },
          ].map(({ label, val, testId }) => (
            <div key={label} className="bg-muted/20 rounded-lg p-2 text-center">
              <div className="text-[10px] text-muted-foreground mb-1">{label}</div>
              <div className={cn("text-xs font-mono font-bold", val >= 0 ? "text-green-400" : "text-red-400")} data-testid={testId}>
                {val >= 0 ? "+" : ""}{val.toFixed(5)}
              </div>
            </div>
          ))}
        </div>
        <p className="text-[11px] text-muted-foreground leading-relaxed">{data.macdExplanation}</p>
      </div>

      {/* ── Bollinger Bands ────────────────────────────────────────────────── */}
      <div className="bg-card border border-border rounded-xl p-3.5">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <Wind className="w-3.5 h-3.5 text-primary" /> Bollinger Bands (20,2)
        </div>
        <div className="space-y-2 mb-2.5">
          {[
            { label: "Dải trên",  val: data.bbUpper,  color: "text-red-400" },
            { label: "Trung tâm", val: data.bbMiddle, color: "text-yellow-400" },
            { label: "Dải dưới",  val: data.bbLower,  color: "text-green-400" },
          ].map(({ label, val, color }) => (
            <div key={label} className="flex justify-between items-center text-xs">
              <span className="text-muted-foreground">{label}</span>
              <span className={cn("font-mono font-semibold", color)}>{fmt(val)}</span>
            </div>
          ))}
        </div>
        {/* %B visual bar */}
        <div className="mb-2.5">
          <div className="flex justify-between text-[10px] text-muted-foreground mb-1">
            <span>%B (vị trí trong dải)</span>
            <span className="font-mono font-bold text-foreground">
              {(data.bbPercent * 100).toFixed(1)}%
            </span>
          </div>
          <div className="h-2 bg-muted rounded-full overflow-hidden relative">
            <div className="absolute inset-0 flex">
              <div className="flex-1 bg-green-500/20" />
              <div className="flex-1 bg-yellow-500/10" />
              <div className="flex-1 bg-red-500/20" />
            </div>
            <div
              className="absolute top-0 bottom-0 w-2 bg-white rounded-full shadow-lg -translate-x-1/2 transition-all duration-700"
              style={{ left: `${Math.min(100, Math.max(0, data.bbPercent * 100))}%` }}
            />
          </div>
          <div className="flex justify-between text-[9px] text-muted-foreground/60 mt-0.5">
            <span>Dải dưới</span>
            <span>Trung tâm</span>
            <span>Dải trên</span>
          </div>
        </div>
        <div className="flex justify-between text-xs mb-2">
          <span className="text-muted-foreground">Độ rộng dải</span>
          <span className={cn("font-mono font-semibold",
            data.bbWidth < 0.03 ? "text-purple-400" : data.bbWidth > 0.08 ? "text-orange-400" : "text-foreground"
          )}>
            {(data.bbWidth * 100).toFixed(2)}%
            {data.bbWidth < 0.03 && <span className="text-[9px] ml-1 text-purple-400">(Nén)</span>}
          </span>
        </div>
        <p className="text-[11px] text-muted-foreground leading-relaxed">{data.bbExplanation}</p>
      </div>

      {/* ── ATR + Volume ───────────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-card border border-border rounded-xl p-3.5">
          <div className="text-[10px] text-muted-foreground uppercase tracking-wide mb-2">ATR (14)</div>
          <div className={cn("text-base font-black font-mono",
            data.atrPercent > 4 ? "text-orange-400" : data.atrPercent > 2 ? "text-yellow-400" : "text-green-400"
          )} data-testid="coin-atr">
            {data.atrPercent.toFixed(2)}%
          </div>
          <div className="text-[10px] text-muted-foreground mt-0.5">${data.atr.toFixed(4)}</div>
          <div className="text-[10px] mt-1.5 leading-relaxed text-muted-foreground line-clamp-3">{data.atrExplanation}</div>
        </div>
        <div className="bg-card border border-border rounded-xl p-3.5">
          <div className="text-[10px] text-muted-foreground uppercase tracking-wide mb-2">Hỗ Trợ / Kháng Cự</div>
          <div className="space-y-1.5">
            <div>
              <div className="text-[9px] text-muted-foreground">Hỗ trợ</div>
              <div className="text-xs font-mono text-green-400 font-semibold" data-testid="coin-support">{fmt(data.support)}</div>
            </div>
            <div>
              <div className="text-[9px] text-muted-foreground">Kháng cự</div>
              <div className="text-xs font-mono text-red-400 font-semibold" data-testid="coin-resistance">{fmt(data.resistance)}</div>
            </div>
          </div>
        </div>
      </div>

      {/* ── Multi-TF Trend ─────────────────────────────────────────────────── */}
      <div className="bg-card border border-border rounded-xl p-3.5">
        <div className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5">
          <TrendingUp className="w-3.5 h-3.5 text-primary" /> Xu Hướng Đa Khung
        </div>
        <div className="grid grid-cols-4 gap-2">
          {[
            { tf: "M15", trend: data.trendM15 },
            { tf: "H1",  trend: data.trendH1 },
            { tf: "H4",  trend: data.trendH4 },
            { tf: "D1",  trend: data.trendD1 },
          ].map(({ tf, trend }) => (
            <div key={tf} className="bg-muted/20 rounded-lg p-2 text-center">
              <div className="text-[10px] text-muted-foreground mb-1">{tf}</div>
              <TrendBadge trend={trend} />
            </div>
          ))}
        </div>
        <p className="text-[11px] text-muted-foreground mt-2.5 leading-relaxed">{data.trendExplanation}</p>
      </div>

      {/* ── Disclaimer ─────────────────────────────────────────────────────── */}
      <div className="flex items-start gap-2 text-xs text-yellow-600/80 bg-yellow-500/8 p-3 rounded-xl border border-yellow-500/20">
        <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
        <p>Thông tin chỉ mang tính tham khảo, không phải lời khuyên đầu tư. Luôn quản lý rủi ro và đặt stop loss.</p>
      </div>
    </div>
  );
}
