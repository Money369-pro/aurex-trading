import {
  useGetScanner, getGetScannerQueryKey,
  useGetAllExchangeSymbols, getGetAllExchangeSymbolsQueryKey,
} from "@workspace/api-client-react";
import { useState, useMemo } from "react";
import { Link } from "wouter";
import { Search as SearchIcon, ArrowUpDown, Globe, LayoutGrid } from "lucide-react";
import { cn } from "@/lib/utils";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";

type ScanTab = "mexc" | "all";

const EXCHANGE_COLORS: Record<string, string> = {
  binance: "text-yellow-400",
  okx:     "text-blue-400",
  bybit:   "text-orange-400",
  mexc:    "text-teal-400",
  kucoin:  "text-green-400",
};

function ExchangeBadge({ name }: { name: string }) {
  return (
    <span className={cn("text-[9px] font-bold uppercase px-1 py-0.5 rounded bg-white/5 border border-white/10", EXCHANGE_COLORS[name] || "text-muted-foreground")}>
      {name}
    </span>
  );
}

export default function Scanner() {
  const [tab, setTab] = useState<ScanTab>("mexc");
  const [search, setSearch] = useState("");
  const [sortField, setSortField] = useState<"score" | "volume24h" | "change24h">("score");
  const [quote, setQuote] = useState("USDT");

  const { data: scanData, isLoading: scanLoading } = useGetScanner({
    query: { queryKey: getGetScannerQueryKey(), enabled: tab === "mexc" },
  });

  const { data: allData, isLoading: allLoading } = useGetAllExchangeSymbols(
    { quote, q: search || undefined, limit: 200, page: 1 },
    { query: { queryKey: [...getGetAllExchangeSymbolsQueryKey({ quote, q: search || undefined, limit: 200, page: 1 })], enabled: tab === "all" } }
  );

  const pairs = useMemo(() => {
    if (!scanData?.pairs) return [];
    let filtered = scanData.pairs;
    if (search) filtered = filtered.filter(p => p.symbol.toLowerCase().includes(search.toLowerCase()));
    return filtered.sort((a, b) => b[sortField] - a[sortField]);
  }, [scanData, search, sortField]);

  const allSymbols = allData?.symbols ?? [];

  return (
    <div className="flex flex-col space-y-3 p-4 h-full">
      <header>
        <h1 className="text-xl font-bold tracking-tight text-white mb-3">Quét Thị Trường</h1>

        <div className="flex gap-1 mb-3 bg-white/5 rounded-xl p-1">
          <button
            onClick={() => setTab("mexc")}
            className={cn(
              "flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all",
              tab === "mexc" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground"
            )}
          >
            <LayoutGrid className="w-3.5 h-3.5" />
            MEXC AI
          </button>
          <button
            onClick={() => { setTab("all"); setSearch(""); }}
            className={cn(
              "flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-all",
              tab === "all" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground"
            )}
          >
            <Globe className="w-3.5 h-3.5" />
            Đa Sàn
          </button>
        </div>

        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder={tab === "mexc" ? "Tìm kiếm mã (VD: BTC)..." : "Tìm coin (VD: ETH)..."}
            className="pl-9 bg-white/5 border-white/10"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>
      </header>

      {tab === "mexc" && (
        <>
          <div className="flex gap-2">
            {(["score", "volume24h", "change24h"] as const).map(field => (
              <button
                key={field}
                onClick={() => setSortField(field)}
                className={cn(
                  "text-xs px-3 py-1.5 rounded-full font-medium transition-colors border",
                  sortField === field
                    ? "bg-primary/20 text-primary border-primary/30"
                    : "bg-white/5 text-muted-foreground border-transparent"
                )}
              >
                {field === "score" ? "Điểm AI" : field === "volume24h" ? "Khối Lượng" : "Biến Động"}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto -mx-4 px-4 pb-10 space-y-2">
            {scanLoading ? (
              [1,2,3,4,5,6].map(i => <Skeleton key={i} className="h-16 w-full rounded-lg" />)
            ) : pairs.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground text-sm">Không tìm thấy kết quả</div>
            ) : (
              pairs.map(pair => (
                <Link key={pair.symbol} href={`/coin/${pair.symbol.replace("/", "_")}`} className="block">
                  <div className="bg-card border border-border hover:bg-white/5 rounded-lg p-3 flex items-center justify-between group">
                    <div className="flex items-center gap-3">
                      <div className={cn("w-1 h-10 rounded-full",
                        pair.score >= 80 ? "bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.5)]" :
                        pair.score >= 65 ? "bg-amber-500" : "bg-muted"
                      )} />
                      <div>
                        <div className="font-bold text-white text-sm">{pair.symbol}</div>
                        <div className="text-[10px] text-muted-foreground flex gap-2">
                          <span>RSI: {pair.rsi.toFixed(1)}</span>
                          <span className={cn(pair.change24h >= 0 ? "text-green-500" : "text-red-500")}>
                            {pair.change24h >= 0 ? "+" : ""}{pair.change24h.toFixed(2)}%
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right flex flex-col items-end">
                      <div className={cn("text-xs font-bold px-1.5 py-0.5 rounded", pair.direction === "LONG" ? "bg-green-500/10 text-green-500" : "bg-red-500/10 text-red-500")}>
                        {pair.direction}
                      </div>
                      <div className="text-xs font-mono text-muted-foreground mt-1">
                        {pair.score} đ
                      </div>
                    </div>
                  </div>
                </Link>
              ))
            )}
          </div>
        </>
      )}

      {tab === "all" && (
        <>
          <div className="flex gap-2">
            {(["USDT", "BTC", "ETH", "BNB"] as const).map(q => (
              <button
                key={q}
                onClick={() => setQuote(q)}
                className={cn(
                  "text-xs px-3 py-1.5 rounded-full font-medium transition-colors border",
                  quote === q
                    ? "bg-primary/20 text-primary border-primary/30"
                    : "bg-white/5 text-muted-foreground border-transparent"
                )}
              >
                {q}
              </button>
            ))}
          </div>

          {allData && (
            <div className="text-[10px] text-muted-foreground">
              {allData.total.toLocaleString()} cặp giao dịch từ 5 sàn
              {allData.cacheAgeSeconds != null && allData.cacheAgeSeconds > 0 && (
                <span className="ml-2">· Cache: {Math.round(allData.cacheAgeSeconds / 60)}p trước</span>
              )}
            </div>
          )}

          <div className="flex-1 overflow-y-auto -mx-4 px-4 pb-10 space-y-2">
            {allLoading ? (
              [1,2,3,4,5,6,7,8].map(i => <Skeleton key={i} className="h-14 w-full rounded-lg" />)
            ) : allSymbols.length === 0 ? (
              <div className="text-center py-10 text-muted-foreground text-sm">Không tìm thấy kết quả</div>
            ) : (
              allSymbols.map(sym => (
                <Link key={sym.symbol} href={`/coin/${sym.symbol.replace("/", "_")}`} className="block">
                  <div className="bg-card border border-border hover:bg-white/5 rounded-lg p-3 flex items-center justify-between">
                    <div>
                      <div className="font-bold text-white text-sm">{sym.symbol}</div>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {sym.exchanges.map(ex => (
                          <ExchangeBadge key={ex} name={ex} />
                        ))}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xs text-muted-foreground">{sym.exchanges.length} sàn</div>
                    </div>
                  </div>
                </Link>
              ))
            )}
          </div>
        </>
      )}
    </div>
  );
}
