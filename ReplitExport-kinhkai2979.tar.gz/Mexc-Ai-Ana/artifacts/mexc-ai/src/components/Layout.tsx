import { ReactNode } from "react";
import { BottomNav } from "./BottomNav";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-[100dvh] w-full bg-background text-foreground flex flex-col md:items-center">
      <main className="flex-1 w-full max-w-md bg-card/30 md:border-x md:border-border shadow-2xl relative pb-20">
        {children}
      </main>
      <BottomNav />
    </div>
  );
}