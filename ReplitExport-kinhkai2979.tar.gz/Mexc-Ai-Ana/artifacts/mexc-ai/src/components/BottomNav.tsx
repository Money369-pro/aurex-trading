import { Link, useLocation } from "wouter";
import { LineChart, Search, Newspaper, Zap, BellRing, Brain } from "lucide-react";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const [location] = useLocation();

  const tabs = [
    { href: "/",        label: "Tổng Quan", icon: LineChart },
    { href: "/scanner", label: "Quét",      icon: Search },
    { href: "/news",    label: "Tin Tức",   icon: Newspaper },
    { href: "/summary", label: "Tóm Tắt",  icon: Zap },
    { href: "/alerts",  label: "Cảnh Báo", icon: BellRing },
    { href: "/review",  label: "Đánh Giá", icon: Brain },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-background/90 backdrop-blur-xl border-t border-border pb-safe">
      <div className="flex items-center justify-around h-14 max-w-md mx-auto px-1">
        {tabs.map((tab) => {
          const isActive = location === tab.href;
          const Icon = tab.icon;

          return (
            <Link key={tab.href} href={tab.href} className="flex-1">
              <div
                data-testid={`nav-${tab.href.replace("/", "") || "home"}`}
                className={cn(
                  "flex flex-col items-center justify-center gap-0.5 py-1.5 rounded-lg transition-all duration-200",
                  isActive
                    ? "text-primary"
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                )}
              >
                <Icon
                  className={cn("w-4.5 h-4.5", isActive && "drop-shadow-[0_0_6px_rgba(0,255,157,0.6)]")}
                  style={{ width: "18px", height: "18px" }}
                  strokeWidth={isActive ? 2.5 : 2}
                />
                <span className="text-[9px] font-medium tracking-tight leading-none">{tab.label}</span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
