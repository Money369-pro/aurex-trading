import { useState, useEffect, useCallback } from "react";
import { useToast } from "./use-toast";

export interface Alert {
  id: string;
  symbol: string;
  condition: ">" | "<";
  price: number;
  createdAt: number;
  triggered: boolean;
}

export function useAlerts() {
  const { toast } = useToast();
  const [alerts, setAlerts] = useState<Alert[]>(() => {
    try {
      const stored = localStorage.getItem("mexc_alerts");
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem("mexc_alerts", JSON.stringify(alerts));
  }, [alerts]);

  const addAlert = useCallback((alert: Omit<Alert, "id" | "createdAt" | "triggered">) => {
    const newAlert: Alert = {
      ...alert,
      id: Math.random().toString(36).substring(7),
      createdAt: Date.now(),
      triggered: false,
    };
    setAlerts((prev) => [...prev, newAlert]);
  }, []);

  const removeAlert = useCallback((id: string) => {
    setAlerts((prev) => prev.filter((a) => a.id !== id));
  }, []);

  const markTriggered = useCallback((id: string) => {
    setAlerts((prev) => prev.map((a) => (a.id === id ? { ...a, triggered: true } : a)));
  }, []);

  const checkPrices = useCallback(
    (prices: Record<string, number>) => {
      alerts.forEach((alert) => {
        if (alert.triggered) return;
        const currentPrice = prices[alert.symbol];
        if (!currentPrice) return;

        let isTriggered = false;
        if (alert.condition === ">" && currentPrice > alert.price) {
          isTriggered = true;
        } else if (alert.condition === "<" && currentPrice < alert.price) {
          isTriggered = true;
        }

        if (isTriggered) {
          toast({
            title: "Cảnh Báo Giá Đã Kích Hoạt!",
            description: `Giá ${alert.symbol} đã ${alert.condition === ">" ? "vượt qua" : "giảm xuống dưới"} ${alert.price} (Giá hiện tại: ${currentPrice})`,
            variant: "default",
          });
          markTriggered(alert.id);
        }
      });
    },
    [alerts, toast, markTriggered]
  );

  return { alerts, addAlert, removeAlert, markTriggered, checkPrices };
}