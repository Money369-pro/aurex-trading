---
name: MEXC AI Analyst architecture
description: Key decisions and constraints for the MEXC AI Analyst trading app
---

**Signal storage:** File-based JSON at `artifacts/api-server/data/signals.json` and `reviews.json`. No DB — chosen for simplicity on Replit free tier.

**Why:** No PostgreSQL configured; file storage is sufficient for a single-user private tool. Signals are deduplicated per symbol per hour using `generateSignalId(symbol, hourKey)`.

**Signal auto-save trigger:** Every call to `GET /api/coins/:symbol` auto-saves the signal if no signal exists for that symbol in the current hour bucket.

**Review timing:** 24h after signal creation. Auto-reviewer runs on a 1-hour `setInterval` started at server boot (`startAutoReviewer()` in `src/index.ts`). `POST /api/reviews/run` allows manual trigger.

**Outcome determination:** Uses kline high/low in the period to check if TP1/TP2/SL was hit (not just current price). This gives accurate backtesting.

**Timeframes fetched on coin detail:** M15, H1, H4, D1 — all stored in the signal for multi-timeframe review.

**Frontend routing:** wouter v3.10, base derived from `import.meta.env.BASE_URL.replace(/\/$/, "")`. All 6 tabs: /, /scanner, /news, /summary, /alerts, /review.

**How to apply:** When extending the review system or adding new signals, always use `generateSignalId` for deduplication and keep the JSON storage pattern consistent.
