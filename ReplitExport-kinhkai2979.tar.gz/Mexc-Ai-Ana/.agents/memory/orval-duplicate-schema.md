---
name: Orval duplicate schema crash
description: orval v8.9.1 gives cryptic "Failed to resolve input" error on duplicate schema names — how to diagnose and fix
---

## The Rule
Never add a schema to openapi.yaml that has the same name as any existing schema. orval v8.9.1 does not report a useful error — it just says "Failed to resolve input: Please provide a valid string value or pass a loader to process the input" with no line number.

**Why:** orval parses the YAML and silently fails on duplicate keys rather than reporting a schema conflict. The error looks like a file-not-found or encoding problem, not a duplicate-key problem, making it very hard to diagnose.

**How to apply:**
1. Before adding any new schema, run: `node -e "const lines=require('fs').readFileSync('lib/api-spec/openapi.yaml','utf8').split('\n'); const c={}; lines.forEach(l=>{const m=l.match(/^    ([A-Za-z][A-Za-z0-9]+):/); if(m)c[m[1]]=(c[m[1]]||0)+1;}); console.log(Object.entries(c).filter(([,v])=>v>1));"` to find duplicates.
2. If a schema you want to add already exists (e.g. `DirectionStats`), rename your new one (e.g. `EvalDirectionStats`) and update all `$ref` references.
3. Also rename the backend TypeScript interface fields to match the schema property names so the actual API response matches generated types.
